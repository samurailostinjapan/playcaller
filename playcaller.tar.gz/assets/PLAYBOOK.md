# Playbook

## Prototype set (chosen 2026-11-01)

**Offense:** Inside Run · Outside Run · Screen · Play-Action Deep
**Defense:** Cover 2 · Man (Cover 1) · Zone Blitz · Run Stuff

### Matchup grid (first guess, tune in testing)

`+` = offense has the edge · `−` = defense has the edge · `0` = even.
An edge shifts the odds; it doesn't guarantee the result (ratings and randomness still play).

| Offense ↓ / Defense → | Cover 2 | Man | Zone Blitz | Run Stuff |
|---|:-:|:-:|:-:|:-:|
| **Inside Run** | + | − | 0 | − |
| **Outside Run** | − | + | + | − |
| **Screen** | 0 | − | + | + |
| **Play-Action Deep** | − | + | − | + |

Why:
- **Inside Run:** Cover 2 has a light box (+); man has an extra defender near the line and Run Stuff has eight in the box (−).
- **Outside Run:** Cover 2 corners force the edge and Run Stuff floods it (−); man defenders chase receivers away and a blitz vacates the edge (+).
- **Screen:** blitzes and an aggressive box run past the RB (+); in man a linebacker sticks to the RB (−).
- **Play-Action Deep:** the run fake pulls Run Stuff and man safeties up (+); Cover 2's two deep safeties sit on it, and a blitz hits the QB before a deep route develops (−).

Balance check: each defense has 2 strengths at most; Screen is the best all-round offense, Inside Run the riskiest; Cover 2 the safest defense, Zone Blitz the most boom-or-bust.

---

## Full list (for later)

### Offense (10)

| # | Play | Type | What happens | Good against | Weak against |
|---|------|------|--------------|--------------|--------------|
| 1 | Inside Run | run | RB hits the gap between the tackles | Prevent, Cover 2 (light box) | Run Stuff, Man (Cover 1), Cover 0 Blitz |
| 2 | Outside Run | run | RB runs wide, tries to turn the corner | Zone Blitz, Man (Cover 1) | Cover 2 (corners force the edge), Run Stuff |
| 3 | Draw | run | Looks like a pass, then a handoff | Blitzes, Prevent | Run Stuff |
| 4 | QB Sneak | run | QB pushes forward behind the center; 1–2 yards | Short yardage vs anything | Long yardage (useless) |
| 5 | Quick Slants | pass | Fast throw to receivers cutting inside | Cover 0 Blitz, Cover 3 | Cover 2, Zone Blitz |
| 6 | Flats / Outs | pass | Short throws to the sideline | Cover 3, Run Stuff | Cover 2 (corners sit there) |
| 7 | Screen | pass | Let the rush in, dump it to the RB behind blockers | Blitzes, Run Stuff | Man (Cover 1), Prevent |
| 8 | Crossers | pass | Receivers cross the middle at different depths | Man (Cover 1), Cover 0 | Cover 3, Prevent |
| 9 | Play-Action Deep | pass | Fake the run, throw deep | Run Stuff, Man (Cover 1) | Cover 2, Zone Blitz, Prevent |
| 10 | Four Verticals | pass | Four receivers go deep | Man (Cover 1), Cover 3 (seams) | Prevent, any blitz that gets home |

### Defense (7)

| # | Call | What happens | Good against | Weak against |
|---|------|--------------|--------------|--------------|
| 1 | Cover 2 | Zone, two deep safeties, corners play short and the edge | Outside Run, Flats, deep balls | Inside Run, Slants between zones |
| 2 | Cover 3 | Zone, three deep, solid vs the run | Crossers, Inside Run | Flats, Slants, seams |
| 3 | Man (Cover 1) | Man coverage, one deep safety, extra defender near the line | Inside Run, Screen, short passes | Outside Run, Crossers, Play-Action Deep |
| 4 | Cover 0 Blitz | Everyone rushes or plays man, nobody deep | Sacks, run stops | Screen, Quick Slants, any open receiver = big play |
| 5 | Zone Blitz | Blitz from one spot, a lineman drops into coverage | Quick Slants, Play-Action Deep | Screen, Draw, Outside Run |
| 6 | Run Stuff | Eight in the box, built to stop the run | All runs | Play-Action Deep, Screen, Flats |
| 7 | Prevent | Everyone deep, gives up short stuff | Deep passes, Four Verticals | Runs, Draw, short passes |

Notes: Sneak is for 3rd/4th and short; Prevent makes sense on long yardage.
