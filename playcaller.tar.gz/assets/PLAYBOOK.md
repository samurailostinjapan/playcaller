# Playbook

## In the game (updated 2026-11-01: the full list, 10 offense × 7 defense)

You pick a **group** first, then a play in it.

| Offense | Plays | Defense | Plays |
|---|---|---|---|
| **Run** | Inside Run · Outside Run · Draw · QB Sneak | **Zone** | Cover 2 · Cover 3 · Prevent |
| **Short** | Screen · Quick Slants · Flats · Crossers | **Attack** | Man · Cover 0 Blitz · Zone Blitz · Run Stuff |
| **Deep** | Play-Action Deep · Four Verticals | | |

### Matchup grid

`+` = offense has the edge · `−` = defense has the edge · `0` = even. An edge shifts the odds; it doesn't decide the play.

| Offense ↓ / Defense → | Cover 2 | Cover 3 | Prevent | Man | Cover 0 Blitz | Zone Blitz | Run Stuff |
|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| **Inside Run** | + | 0 | + | − | − | 0 | − |
| **Outside Run** | 0 | + | 0 | 0 | − | + | − |
| **Draw** | 0 | − | + | 0 | + | + | − |
| **QB Sneak** | + | 0 | + | 0 | − | 0 | − |
| **Screen** | 0 | − | − | − | + | + | + |
| **Quick Slants** | − | + | + | 0 | 0 | − | + |
| **Flats** | − | + | + | − | + | 0 | + |
| **Crossers** | 0 | 0 | − | + | + | 0 | 0 |
| **Play-Action Deep** | − | − | − | + | − | − | + |
| **Four Verticals** | + | + | − | + | − | − | 0 |

Why, in short:
- **Runs** beat light boxes (Cover 2, Prevent) and die against Run Stuff and Cover 0 (everyone's in the box). Cover 3 corners bail deep, so Outside Run gets the edge there.
- **QB Sneak** gains a yard or two whatever the matchup: it's for 3rd/4th and short only. The edge just decides how often it gets there.
- **Draw** punishes defenses that rush upfield or drop deep (both blitzes, Prevent); Cover 3 keeps enough defenders home.
- **Screen** beats blitzes and loaded boxes; Cover 3 and Prevent have people underneath, and in man a linebacker sticks to the RB.
- **Quick Slants** hit the windows in Cover 3 and get in front of Prevent; Cover 2 linebackers and a zone blitz's dropping lineman sit in the throwing lane.
- **Flats** live where Cover 3 and Prevent leave room; Cover 2 corners sit right there, man corners jump the out.
- **Crossers** run away from man coverage and Cover 0; Prevent's deep zones swallow them.
- **Play-Action Deep** beats man and Run Stuff (the fake pulls defenders up); every deep zone and every blitz takes it away.
- **Four Verticals** stretch Cover 2 and Cover 3 at the seams and beat man; Prevent and blitzes that get home kill it.
- **Cover 0 Blitz** is high risk: nobody deep, so anything that beats the first wave can go the distance (extra big-play chance).
- **Prevent** is for long yardage: it gives up short gains on purpose.

Balance (simulated 2026-11-01, 4000 drives each): calling one play every snap beats random calling by at most ~10 points on Easy/Medium (they don't adapt) and loses badly on Hard, on both sides of the ball. Random calling scores on about 21% of drives at every difficulty.

---

## Original draft (all in the game now; the grid above is what the game uses)

### Offense (10)

| # | Play | Type | What happens | Good against | Weak against |
|---|------|------|--------------|--------------|--------------|
| 1 | Inside Run | run | RB hits the gap between the tackles | Prevent, Cover 2 (light box) | Run Stuff, Man (Cover 1), Cover 0 Blitz |
| 2 | Outside Run | run | RB runs wide, tries to turn the corner | Zone Blitz, Man (Cover 1) | Cover 2 (corners force the edge), Run Stuff |
| 3 | Draw | run | Looks like a pass, then a handoff | Blitzes, Prevent | Run Stuff |
| 4 | QB Sneak | run | QB pushes forward behind the center; 1–2 yards | Short yardage vs anything | Long yardage (useless) |
| 5 | Quick Slants | pass | Fast throw to receivers cutting inside | Cover 0 Blitz, Cover 3 | Cover 2, Zone Blitz |
| 6 | Flats / Outs | pass | Short throws to the sideline | Cover 3, Run Stuff | Cover 2 (corners sit there) |
| 7 | Screen | pass | Let the rush in, dump it to the RB behind blockers | Blitzes, Run Stuff | Man (Cover 1), Prevent |
| 8 | Crossers | pass | Receivers cross the middle at different depths | Man (Cover 1), Cover 0 | Cover 3, Prevent |
| 9 | Play-Action Deep | pass | Fake the run, throw deep | Run Stuff, Man (Cover 1) | Cover 2, Zone Blitz, Prevent |
| 10 | Four Verticals | pass | Four receivers go deep | Man (Cover 1), Cover 3 (seams) | Prevent, any blitz that gets home |

### Defense (7)

| # | Call | What happens | Good against | Weak against |
|---|------|--------------|--------------|--------------|
| 1 | Cover 2 | Zone, two deep safeties, corners play short and the edge | Outside Run, Flats, deep balls | Inside Run, Slants between zones |
| 2 | Cover 3 | Zone, three deep, solid vs the run | Crossers, Inside Run | Flats, Slants, seams |
| 3 | Man (Cover 1) | Man coverage, one deep safety, extra defender near the line | Inside Run, Screen, short passes | Outside Run, Crossers, Play-Action Deep |
| 4 | Cover 0 Blitz | Everyone rushes or plays man, nobody deep | Sacks, run stops | Screen, Quick Slants, any open receiver = big play |
| 5 | Zone Blitz | Blitz from one spot, a lineman drops into coverage | Quick Slants, Play-Action Deep | Screen, Draw, Outside Run |
| 6 | Run Stuff | Eight in the box, built to stop the run | All runs | Play-Action Deep, Screen, Flats |
| 7 | Prevent | Everyone deep, gives up short stuff | Deep passes, Four Verticals | Runs, Draw, short passes |

Notes: Sneak is for 3rd/4th and short; Prevent makes sense on long yardage.
