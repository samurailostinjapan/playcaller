"""The computer's play-calling, by difficulty.

Easy:   random.
Medium: plays the situation (down, distance, field position).
Hard:   plays the situation AND learns your calls during the drive, then leans
        toward whatever beats what you've been doing.
"""

from collections import Counter
import math
import random

from .plays import OFFENSE, DEFENSE, RUNS, edge

DIFFICULTIES = ["Easy", "Medium", "Hard"]


def _bucket(down: int, to_go: int) -> str:
    """short / medium / long yardage. 1st & 10 is a neutral down, not long yardage."""
    if to_go <= 3:
        return "short"
    if to_go > 10 or (down >= 2 and to_go >= 8) or (down >= 3 and to_go >= 6):
        return "long"
    return "medium"


def _situation_weights(side: str, down: int, to_go: int) -> dict[str, float]:
    b = _bucket(down, to_go)
    if side == "offense":   # computer has the ball
        return {
            "short":  {"Inside Run": 4,   "Outside Run": 2, "Draw": 1,   "Screen": 1.5, "Quick Slants": 2,   "Play-Action Deep": 1.5},
            "medium": {"Inside Run": 2,   "Outside Run": 2, "Draw": 1.5, "Screen": 2,   "Quick Slants": 2,   "Play-Action Deep": 2},
            "long":   {"Inside Run": 0.7, "Outside Run": 1, "Draw": 2,   "Screen": 3,   "Quick Slants": 2.5, "Play-Action Deep": 3.5},
        }[b]
    return {                # computer on defense
        "short":  {"Cover 2": 0.8, "Cover 3": 1.5, "Prevent": 0.1, "Man": 2.5, "Zone Blitz": 1.5, "Run Stuff": 4},
        "medium": {"Cover 2": 2,   "Cover 3": 2,   "Prevent": 0.3, "Man": 2,   "Zone Blitz": 2,   "Run Stuff": 2},
        "long":   {"Cover 2": 3.5, "Cover 3": 2,   "Prevent": 2,   "Man": 1.5, "Zone Blitz": 2,   "Run Stuff": 0.7},
    }[b]


def _pick(rng: random.Random, weights: dict[str, float]) -> str:
    plays = list(weights)
    return rng.choices(plays, weights=[weights[p] for p in plays])[0]


class Computer:
    def __init__(self, difficulty: str, side: str, rng: random.Random):
        self.difficulty = difficulty
        self.side = side                      # the side the COMPUTER plays
        self.rng = rng
        self.seen: dict[str, Counter] = {}    # your calls, by situation bucket

    def observe(self, down: int, to_go: int, your_play: str) -> None:
        self.seen.setdefault(_bucket(down, to_go), Counter())[your_play] += 1

    def call(self, down: int, to_go: int) -> str:
        mine = OFFENSE if self.side == "offense" else DEFENSE
        if self.difficulty == "Easy":
            return self.rng.choice(mine)
        weights = _situation_weights(self.side, down, to_go)
        if self.difficulty == "Hard":
            weights = self._counter(weights, down, to_go)
        return _pick(self.rng, weights)

    def _counter(self, weights: dict[str, float], down: int, to_go: int) -> dict[str, float]:
        """Blend in what beats your habits. Uses this situation if seen, else all calls."""
        seen = self.seen.get(_bucket(down, to_go)) or sum(self.seen.values(), Counter())
        total = sum(seen.values())
        if total < 2:
            return weights
        sign = 1 if self.side == "offense" else -1
        out = {}
        for mine in weights:
            # expected edge for the computer against your observed habits
            exp = sum(n * (edge(mine, yours) if self.side == "offense" else edge(yours, mine))
                      for yours, n in seen.items()) / total
            out[mine] = weights[mine] * math.exp(2.4 * sign * exp)   # how hard Hard leans on your habits
        return out


def is_run(play: str) -> bool:
    return play in RUNS
