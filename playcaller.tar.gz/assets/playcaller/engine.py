"""Game rules and play resolution. No pygame here, so it can be tested on its own.

Field coordinates: yards from the offense's own goal line. 0 = own goal line,
100 = the opponent's goal line (touchdown). A drive starts at 20.
"""

from dataclasses import dataclass, field
import random

from .plays import RUNS, edge

START_SPOT = 20
FIRST_DOWN = 10


@dataclass
class Result:
    offense_play: str
    defense_play: str
    edge: int
    kind: str                 # "run", "catch", "incomplete", "sack", "interception", "fumble"
    yards: int                # net yards for the offense (0 for incomplete/interception)
    big_play: bool = False

    def describe(self) -> str:
        y = self.yards
        gain = f"gain of {y}" if y > 0 else ("no gain" if y == 0 else f"loss of {-y}")
        return {
            "run": f"Run, {gain}.",
            "catch": f"Pass complete, {gain}.",
            "incomplete": "Pass incomplete.",
            "sack": f"Sacked, {gain}.",
            "interception": "Intercepted!",
            "fumble": f"Fumble! Defense recovers after a {gain}.",
        }[self.kind]


def _run(rng: random.Random, e: int, outside: bool) -> tuple[str, int, bool]:
    if rng.random() < 0.015:
        return "fumble", round(rng.gauss(2, 2)), False
    if outside:   # boom or bust
        mean, sd = {+1: (7, 6), 0: (3.5, 5), -1: (-0.5, 3.5)}[e]
    else:         # steady
        mean, sd = {+1: (5.5, 3), 0: (3.5, 2.5), -1: (1.5, 2)}[e]
    yards = round(rng.gauss(mean, sd))
    big = e >= 0 and rng.random() < (0.08 if outside else 0.04)
    if big:
        yards = max(yards, 0) + rng.randint(15, 40)
    return "run", yards, big


def _draw(rng: random.Random, e: int) -> tuple[str, int, bool]:
    if rng.random() < 0.015:
        return "fumble", round(rng.gauss(2, 2)), False
    mean, sd = {+1: (6, 4), 0: (3, 3), -1: (0.5, 2.5)}[e]
    yards = round(rng.gauss(mean, sd))
    big = e >= 0 and rng.random() < 0.06
    if big:
        yards = max(yards, 0) + rng.randint(12, 35)
    return "run", yards, big


def _slants(rng: random.Random, e: int) -> tuple[str, int, bool]:
    if rng.random() < {+1: 0.01, 0: 0.025, -1: 0.05}[e]:
        return "interception", 0, False
    if rng.random() < {+1: 0.18, 0: 0.33, -1: 0.45}[e]:
        return "incomplete", 0, False
    mean, sd = {+1: (8, 4), 0: (5, 3), -1: (3, 2.5)}[e]
    yards = max(1, round(rng.gauss(mean, sd)))
    big = e == +1 and rng.random() < 0.08
    if big:
        yards += rng.randint(10, 30)
    return "catch", yards, big


def _screen(rng: random.Random, e: int) -> tuple[str, int, bool]:
    if rng.random() < {+1: 0.03, 0: 0.08, -1: 0.15}[e]:
        return "incomplete", 0, False
    if e == -1 and rng.random() < 0.04:
        return "interception", 0, False
    mean, sd = {+1: (8, 5), 0: (4, 3.5), -1: (0, 3)}[e]
    yards = round(rng.gauss(mean, sd))
    big = e == +1 and rng.random() < 0.08
    if big:
        yards = max(yards, 0) + rng.randint(15, 45)
    return "catch", yards, big


def _deep(rng: random.Random, e: int, d: "Drive") -> tuple[str, int, bool]:
    if rng.random() < {+1: 0.03, 0: 0.07, -1: 0.15}[e]:
        return "sack", -rng.randint(5, 10), False
    if rng.random() < {+1: 0.02, 0: 0.04, -1: 0.08}[e]:
        return "interception", 0, False
    if rng.random() < {+1: 0.55, 0: 0.38, -1: 0.22}[e]:
        yards = rng.randint(18, 40)
        big = rng.random() < {+1: 0.14, 0: 0.06, -1: 0.02}[e]   # tuned 2026-11-01: was 35% / 15%
        if big:
            yards = 100 - d.spot   # caught in stride, goes the distance
        return "catch", yards, big
    return "incomplete", 0, False


def _sneak(rng: random.Random, e: int) -> tuple[str, int, bool]:
    """Short yardage only: a yard or two, almost never more."""
    if rng.random() < 0.01:
        return "fumble", 0, False
    mean = {+1: 2.2, 0: 1.5, -1: 0.6}[e]
    yards = max(-1, round(rng.gauss(mean, 1.1)))
    big = e >= 0 and rng.random() < 0.015
    if big:
        yards += rng.randint(5, 15)
    return "run", yards, big


def _flats(rng: random.Random, e: int) -> tuple[str, int, bool]:
    if rng.random() < {+1: 0.01, 0: 0.02, -1: 0.045}[e]:
        return "interception", 0, False
    if rng.random() < {+1: 0.14, 0: 0.24, -1: 0.36}[e]:
        return "incomplete", 0, False
    mean, sd = {+1: (6, 3), 0: (4, 2.5), -1: (2, 2)}[e]
    yards = max(1, round(rng.gauss(mean, sd)))
    big = e == +1 and rng.random() < 0.05
    if big:
        yards += rng.randint(10, 25)
    return "catch", yards, big


def _crossers(rng: random.Random, e: int) -> tuple[str, int, bool]:
    if rng.random() < {+1: 0.02, 0: 0.05, -1: 0.09}[e]:
        return "sack", -rng.randint(4, 8), False
    if rng.random() < {+1: 0.015, 0: 0.03, -1: 0.06}[e]:
        return "interception", 0, False
    if rng.random() < {+1: 0.25, 0: 0.42, -1: 0.50}[e]:
        return "incomplete", 0, False
    mean, sd = {+1: (11, 4), 0: (7, 3.5), -1: (5, 3)}[e]
    yards = max(2, round(rng.gauss(mean, sd)))
    big = rng.random() < {+1: 0.10, 0: 0.04, -1: 0.0}[e]
    if big:
        yards += rng.randint(10, 35)
    return "catch", yards, big


def _verticals(rng: random.Random, e: int, d: "Drive") -> tuple[str, int, bool]:
    if rng.random() < {+1: 0.04, 0: 0.08, -1: 0.16}[e]:
        return "sack", -rng.randint(5, 10), False
    if rng.random() < {+1: 0.025, 0: 0.05, -1: 0.10}[e]:
        return "interception", 0, False
    if rng.random() < {+1: 0.42, 0: 0.32, -1: 0.18}[e]:
        yards = rng.randint(15, 35)
        big = rng.random() < {+1: 0.09, 0: 0.05, -1: 0.02}[e]
        if big:
            yards = 100 - d.spot
        return "catch", yards, big
    return "incomplete", 0, False


@dataclass
class Drive:
    spot: int = START_SPOT
    down: int = 1
    to_go: int = FIRST_DOWN
    over: bool = False
    winner: str | None = None        # "offense" or "defense"
    reason: str = ""
    history: list = field(default_factory=list)

    @property
    def line_to_gain(self) -> int:
        return min(self.spot + self.to_go, 100)

    def situation(self) -> str:
        names = {1: "1st", 2: "2nd", 3: "3rd", 4: "4th"}
        to_go = "Goal" if self.line_to_gain >= 100 else str(self.to_go)
        return f"{names[self.down]} & {to_go} on {ball_on(self.spot)}"

    def resolve(self, offense_play: str, defense_play: str, rng: random.Random) -> Result:
        """Decide what happens on this play. Does not change the drive."""
        e = edge(offense_play, defense_play)
        if offense_play == "Draw":
            kind, yards, big = _draw(rng, e)
        elif offense_play == "QB Sneak":
            kind, yards, big = _sneak(rng, e)
        elif offense_play in RUNS:
            kind, yards, big = _run(rng, e, outside=offense_play == "Outside Run")
        elif offense_play == "Quick Slants":
            kind, yards, big = _slants(rng, e)
        elif offense_play == "Flats":
            kind, yards, big = _flats(rng, e)
        elif offense_play == "Crossers":
            kind, yards, big = _crossers(rng, e)
        elif offense_play == "Screen":
            kind, yards, big = _screen(rng, e)
        elif offense_play == "Four Verticals":
            kind, yards, big = _verticals(rng, e, self)
        else:
            kind, yards, big = _deep(rng, e, self)
        # Cover 0 has nobody deep: anything that gets past the first wave can go a long way
        if (defense_play == "Cover 0 Blitz" and kind in ("run", "catch") and not big
                and offense_play != "QB Sneak" and rng.random() < {+1: 0.12, 0: 0.05, -1: 0.0}[e]):
            yards, big = max(yards, 0) + rng.randint(15, 40), True
        yards = max(min(yards, 100 - self.spot), -self.spot)   # stay on the field
        return Result(offense_play, defense_play, e, kind, yards, big)

    def apply(self, r: Result) -> None:
        """Move the drive forward with a resolved play and check for a winner."""
        self.history.append((self.situation(), r))
        if r.kind in ("interception", "fumble"):
            return self._end("defense", "Turnover")
        self.spot += r.yards
        if self.spot >= 100:
            return self._end("offense", "Touchdown")
        if self.spot <= 0:
            return self._end("defense", "Safety")
        self.to_go -= r.yards
        if self.to_go <= 0:
            self.down, self.to_go = 1, min(FIRST_DOWN, 100 - self.spot)
        elif self.down == 4:
            return self._end("defense", "Turnover on downs")
        else:
            self.down += 1

    def _end(self, winner: str, reason: str) -> None:
        self.over, self.winner, self.reason = True, winner, reason


def ball_on(spot: int) -> str:
    if spot == 50:
        return "the 50"
    return f"own {spot}" if spot < 50 else f"opp {100 - spot}"
