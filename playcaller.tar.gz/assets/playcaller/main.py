"""PlayCaller: pick a side, pick a difficulty, call plays, watch them run."""

if __package__ in (None, ""):          # started as a file (py main.py inside playcaller/)
    import pathlib
    import sys
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
    __package__ = "playcaller"
    import playcaller  # noqa: F401  (sets up the package before the relative imports)

import asyncio
import random
import sys
import pygame

from . import render as R
from .ai import Computer, DIFFICULTIES
from .anim import build
from .engine import Drive
from .plays import OFFENSE, DEFENSE, OFFENSE_GROUPS, DEFENSE_GROUPS, DESCRIPTION

WEB = sys.platform == "emscripten"   # running in a browser (pygbag)

KEYS_1_4 = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
            pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3}


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("PlayCaller")
        self.screen = pygame.display.set_mode((R.W, R.H))
        self.fonts = R.Fonts()
        self.clock = pygame.time.Clock()
        self.rng = random.Random()
        self.state = "side"
        self.side = None            # the side YOU play
        self.difficulty = None
        self.choice = 0             # play within the open group
        self.group = None           # None = picking a group; else the group's name
        self.gchoice = 0            # highlighted group
        self.drive = None
        self.cpu = None
        self.scene = None
        self.t = 0.0
        self.last = None            # (your call, cpu call, result)
        self.preview = None

    # ---------- flow ----------
    def new_drive(self):
        self.drive = Drive()
        cpu_side = "defense" if self.side == "offense" else "offense"
        self.cpu = Computer(self.difficulty, cpu_side, self.rng)
        self.choice, self.last, self.state = 0, None, "call"
        self.group, self.gchoice = None, 0
        self.preview = None

    def groups(self) -> dict:
        return OFFENSE_GROUPS if self.side == "offense" else DEFENSE_GROUPS

    def my_plays(self):
        return self.groups()[self.group]

    def snap(self):
        d = self.drive
        mine = self.my_plays()[self.choice]
        cpu = self.cpu.call(d.down, d.to_go)
        self.cpu.observe(d.down, d.to_go, mine)
        off, de = (mine, cpu) if self.side == "offense" else (cpu, mine)
        result = d.resolve(off, de, self.rng)
        self.scene = build(result, d.spot, self.rng)
        self.last = (mine, cpu, result, d.situation())
        self.t, self.state = 0.0, "play"

    def finish_play(self):
        self.drive.apply(self.last[2])
        self.state = "over" if self.drive.over else "result"

    # ---------- input ----------
    def key(self, k):
        if k == pygame.K_ESCAPE:
            if self.state in ("side", "over") and not WEB:   # in a browser there's nothing to quit to
                raise SystemExit
            self.state = "side"
            return
        if self.state == "side":
            if k in (pygame.K_o, pygame.K_1):
                self.side, self.state = "offense", "difficulty"
            elif k in (pygame.K_d, pygame.K_2):
                self.side, self.state = "defense", "difficulty"
        elif self.state == "difficulty":
            if k in KEYS_1_4 and KEYS_1_4[k] < 3:
                self.difficulty = DIFFICULTIES[KEYS_1_4[k]]
                self.new_drive()
        elif self.state == "call" and self.group is None:          # step 1: Run/Pass or Zone/Attack
            names = list(self.groups())
            letters = {pygame.key.key_code(n[0].lower()): i for i, n in enumerate(names)}
            if k in KEYS_1_4 and KEYS_1_4[k] < len(names):
                self.gchoice = KEYS_1_4[k]
                self.group, self.choice = names[self.gchoice], 0
            elif k in letters:
                self.gchoice = letters[k]
                self.group, self.choice = names[self.gchoice], 0
            elif k in (pygame.K_UP, pygame.K_LEFT, pygame.K_DOWN, pygame.K_RIGHT):
                self.gchoice = (self.gchoice + 1) % len(names)
            elif k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.group, self.choice = names[self.gchoice], 0
        elif self.state == "call":                                 # step 2: the play
            n = len(self.my_plays())
            if k in KEYS_1_4 and KEYS_1_4[k] < n:
                self.choice = KEYS_1_4[k]
            elif k in (pygame.K_UP, pygame.K_LEFT):
                self.choice = (self.choice - 1) % n
            elif k in (pygame.K_DOWN, pygame.K_RIGHT):
                self.choice = (self.choice + 1) % n
            elif k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.snap()
            elif k == pygame.K_BACKSPACE:
                self.group = None
        elif self.state == "play":
            if k in (pygame.K_SPACE, pygame.K_RETURN):
                self.t = self.scene.duration
        elif self.state == "result":
            if k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.state, self.group = "call", None
        elif self.state == "over":
            if k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.new_drive()
            elif k == pygame.K_n:
                self.state = "side"

    # ---------- drawing ----------
    def draw(self):
        s, f = self.screen, self.fonts
        s.fill(R.BG)
        if self.state == "side":
            return self.draw_menu("Pick your side", ["1 / O   Offense: drive 80 yards for a touchdown",
                                                     "2 / D   Defense: stop them on downs"])
        if self.state == "difficulty":
            return self.draw_menu(f"You play {self.side}. Pick a difficulty",
                                  ["1   Easy: the computer calls at random",
                                   "2   Medium: it plays the down and distance",
                                   "3   Hard: it also learns your habits"])
        d = self.drive
        # top bar
        R.text(s, f.bold, "PlayCaller", (R.FX, 22), R.BLUE)
        R.text(s, f.body, f"You: {self.side.capitalize()}  ·  {self.difficulty}", (R.FX + 150, 24), R.DIM)
        sit = self.last[3] if self.state in ("play", "over") else d.situation()
        R.text(s, f.bold, sit, (R.W - R.FX - f.bold.size(sit)[0], 22))
        # field + players
        if self.state == "play":            # drive not updated yet: lines are pre-snap
            R.field(s, f, self.scene.los, d.line_to_gain)
            R.players(s, self.scene, self.t)
        elif self.state in ("result", "over"):
            R.field(s, f, self.scene.los, None)
            R.players(s, self.scene, self.scene.duration)
        else:
            if self.preview is None or self.preview.los != d.spot:
                self.preview = build(d.resolve(OFFENSE[0], DEFENSE[0], random.Random(0)),
                                     d.spot, random.Random(0))
            R.field(s, f, d.spot, d.line_to_gain)
            R.players(s, self.preview, 0.0)
        # bottom panel
        top = R.FY + R.FIELD_H + 16
        R.panel(s, (R.FX, top, 120 * R.PPY, R.H - top - 16))
        if self.state == "call":
            self.draw_call(top)
        elif self.state == "play":
            self.hint("Space: skip", top)
            self.draw_calls_line(top + 16)
        elif self.state == "result":
            self.draw_result(top)
            self.hint("Space: next play", top)
        elif self.state == "over":
            self.draw_result(top)
            won = (d.winner == self.side)
            msg = ("YOU WIN" if won else "YOU LOSE") + f": {d.reason}"
            R.banner(s, f.huge, msg, R.GREEN if won else R.RED)
            self.hint("Enter: play again  ·  N or Esc: new side/difficulty" if WEB else
                      "Enter: play again  ·  N: new side/difficulty  ·  Esc: quit", top)

    def hint(self, s, top):
        f = self.fonts.body
        R.text(self.screen, f, s, (R.FX + 120 * R.PPY - 20 - f.size(s)[0], top + 16), R.DIM)

    def draw_menu(self, title, lines):
        s, f = self.screen, self.fonts
        R.text(s, f.huge, "PlayCaller", (R.W // 2, 170), R.BLUE, center=True)
        R.text(s, f.body, "One drive. Touchdown or nothing.", (R.W // 2, 230), R.DIM, center=True)
        R.text(s, f.big, title, (R.W // 2, 330), R.TEXT, center=True)
        for i, line in enumerate(lines):
            R.text(s, f.bold, line, (R.W // 2 - 300, 400 + i * 50), R.TEXT)
        if not WEB:
            R.text(s, f.small, "Esc: quit", (R.W // 2, R.H - 40), R.DIM, center=True)

    def card(self, x, top, w, sel, title, sub):
        s, f = self.screen, self.fonts
        rect = (x - 8, top + 44, w, 84)
        pygame.draw.rect(s, (52, 59, 88) if sel else R.BG, rect, border_radius=6)
        if sel:
            pygame.draw.rect(s, R.BLUE, rect, 2, border_radius=6)
        R.text(s, f.bold, title, (x, top + 52), R.BLUE if sel else R.TEXT)
        R.wrap(s, f.small, sub, (x, top + 84), w - 16, R.DIM, 19)

    def draw_call(self, top):
        s, f = self.screen, self.fonts
        what = "play" if self.side == "offense" else "defense"
        if self.group is None:
            names = list(self.groups())
            keys = " / ".join(n[0] for n in names)
            R.text(s, f.body, f"Call your {what}: pick a group   (1–2 or {keys}, arrows + Enter)",
                   (R.FX + 20, top + 12), R.DIM)
            for i, name in enumerate(names):
                self.card(R.FX + 20 + i * 596, top, 576, i == self.gchoice,
                          f"{i + 1}  {name}", "  ·  ".join(self.groups()[name]))
        else:
            R.text(s, f.body, f"{self.group}: pick the {what}   (1–3 or arrows, Enter to snap, Backspace: back)",
                   (R.FX + 20, top + 12), R.DIM)
            for i, name in enumerate(self.my_plays()):
                self.card(R.FX + 20 + i * 396, top, 380, i == self.choice, f"{i + 1}  {name}", DESCRIPTION[name])
        if self.last and self.group is None:
            mine, cpu, res, _ = self.last
            self.hint(f"Last: you {mine}, CPU {cpu}: {res.describe()}", top - 4)

    def draw_calls_line(self, y):
        s, f = self.screen, self.fonts
        mine, cpu, _, _ = self.last
        R.text(s, f.bold, f"You: {mine}", (R.FX + 20, y), R.BLUE if self.side == "offense" else R.RED)
        R.text(s, f.bold, f"CPU: {cpu}", (R.FX + 380, y), R.RED if self.side == "offense" else R.BLUE)

    def draw_result(self, top):
        s, f = self.screen, self.fonts
        mine, cpu, res, _ = self.last
        self.draw_calls_line(top + 16)
        edge = {1: "Offense had the edge", 0: "Even matchup", -1: "Defense had the edge"}[res.edge]
        R.text(s, f.bold, res.describe(), (R.FX + 20, top + 56), R.YELLOW)
        R.text(s, f.body, edge, (R.FX + 20, top + 88), R.DIM)

    # ---------- loop ----------
    async def run(self):
        while True:
            dt = self.clock.tick(60) / 1000
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return
                if e.type == pygame.KEYDOWN:
                    try:
                        self.key(e.key)
                    except SystemExit:
                        return
            if self.state == "play":
                self.t += dt
                if self.t >= self.scene.duration:
                    self.finish_play()
            self.draw()
            pygame.display.flip()
            await asyncio.sleep(0)       # lets the browser breathe (web build); harmless on desktop


async def amain():
    await Game().run()
    pygame.quit()


def main():
    asyncio.run(amain())


if __name__ == "__main__":
    main()
