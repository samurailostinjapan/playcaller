"""PlayCaller: pick a side, pick a difficulty, call plays, watch them run."""

if __package__ in (None, ""):          # started as a file (py main.py inside playcaller/)
    import pathlib
    import sys
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
    __package__ = "playcaller"
    import playcaller  # noqa: F401  (sets up the package before the relative imports)

import asyncio
import os
import random
import sys
import pygame

from . import render as R
from .ai import Computer, DIFFICULTIES
from .anim import build, preview, holder_at_end
from .engine import Drive
from .plays import OFFENSE, DEFENSE, OFFENSE_GROUPS, DEFENSE_GROUPS, DESCRIPTION

WEB = sys.platform == "emscripten"   # running in a browser (pygbag)
BUILD = "2026-11-02d"                # shown on the start screen: tells you which version the browser loaded
SCREEN_INFO = "desktop"              # what phone_size() saw (start screen, for checking phone mode)
PANEL_W = 350                        # phone mode: width of the side panel


def phone_size():
    """Phone mode screen size, or None for the normal layout.

    A phone held sideways only has ~350 px of height, so the 1280x780 layout comes out at under half size.
    Phone mode draws a short 444-px-tall screen instead (the browser then scales it UP), with the field on
    the left and a panel on the right. PLAYCALLER_PHONE=1 (or a width, e.g. 800) tries it on the desktop.
    """
    global SCREEN_INFO
    env = os.environ.get("PLAYCALLER_PHONE")
    if env:
        return (int(env) if env.isdigit() and int(env) > 1 else 900), 444
    if WEB:
        try:
            import platform as browser                     # pygbag's bridge to the page
            win = browser.window
            w, h = int(win.innerWidth), int(win.innerHeight)
            # the device's screen too: the window can be odd while the page is still loading
            dw, dh = int(win.screen.width), int(win.screen.height)
        except Exception as e:
            SCREEN_INFO = f"no size ({type(e).__name__})"
            return None
        SCREEN_INFO = f"window {w}x{h}, screen {dw}x{dh}"
        if min(w, h) < 600 or min(dw, dh) < 600:
            w, h = max(w, h, dw, dh), min(min(w, h), min(dw, dh))                                # phone-sized screen
            aspect = max(w, h) / min(w, h)                 # match a sideways phone's shape
            return int(min(1000, max(760, 444 * aspect))), 444
    return None

KEYS_1_4 = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
            pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3}


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("PlayCaller")
        size = phone_size()
        self.phone = size is not None
        self.screen = pygame.display.set_mode(size or (R.W, R.H))
        self.full = pygame.Surface((R.W, R.H), 0, 24) if self.phone else None   # phone: field drawn here
        self.fonts = R.Fonts()
        self.clock = pygame.time.Clock()
        self.rng = random.Random()
        self.state = "side"
        self.side = None            # the side YOU play
        self.difficulty = None
        self.choice = 0             # play within the open group
        self.group = None           # None = picking a group; else the group's name
        self.gchoice = 0            # highlighted group
        self.drive = None
        self.cpu = None
        self.scene = None
        self.t = 0.0
        self.last = None            # (your call, cpu call, result)
        self.preview = None
        self.formation = None
        self.moments = []           # times of the big moments in the current play (slow motion)
        self.ltg = None
        self.after = None           # the state a replay returns to
        self.follow = True          # camera follows the ball during plays (C toggles)
        self.cam = (0.0, 0.0)       # camera center, yards
        # the field is drawn here, then the camera crops it. 24-bit on purpose: a copy of the display
        # format can carry an alpha channel, and then everything drawn on it comes out invisible
        self.world = pygame.Surface((R.W, R.H), 0, 24)
        self.taps = []              # (rect, action) for touch/mouse, rebuilt every frame by draw()

    # ---------- flow ----------
    def new_drive(self):
        self.drive = Drive()
        cpu_side = "defense" if self.side == "offense" else "offense"
        self.cpu = Computer(self.difficulty, cpu_side, self.rng)
        self.choice, self.last, self.state = 0, None, "call"
        self.group, self.gchoice = None, 0
        self.preview = None

    def groups(self) -> dict:
        return OFFENSE_GROUPS if self.side == "offense" else DEFENSE_GROUPS

    def my_plays(self):
        return self.groups()[self.group]

    def snap(self):
        d = self.drive
        mine = self.my_plays()[self.choice]
        cpu = self.cpu.call(d.down, d.to_go)
        self.cpu.observe(d.down, d.to_go, mine)
        off, de = (mine, cpu) if self.side == "offense" else (cpu, mine)
        result = d.resolve(off, de, self.rng)
        self.scene = build(result, d.spot, self.rng)
        self.last = (mine, cpu, result, d.situation())
        self.t, self.state = 0.0, "play"
        self.cam = R.camera_target(self.scene, 0.0)
        self.ltg = d.line_to_gain                # pre-snap line to gain, for the replay
        big = {"int", "sack", "fumble", "td"}
        self.moments = [e[0] for e in self.scene.events
                        if e[1] in big or (e[1] == "catch" and result.yards >= 15)]

    def speed(self):
        """1.0 normally; slow motion for about a second around the play's big moment."""
        for te in self.moments:
            if -0.35 < self.t - te < 0.6:
                return 0.3
        return 1.0

    def start_replay(self):
        self.after, self.state = self.state, "replay"
        # start just before the big moment (whole play if there wasn't one)
        self.t = max(0.0, self.moments[0] - 1.5) if self.moments else 0.0
        self.cam = R.camera_target(self.scene, self.t)

    def finish_play(self):
        self.drive.apply(self.last[2])
        self.state = "over" if self.drive.over else "result"

    def update_camera(self, dt):
        if self.scene is None:
            return
        t = self.t if self.state in ("play", "replay") else self.scene.duration
        tx, ty = R.camera_target(self.scene, t)
        k = min(1.0, dt * 4.0)                  # ease toward the ball, no jerky jumps
        self.cam = (self.cam[0] + (tx - self.cam[0]) * k, self.cam[1] + (ty - self.cam[1]) * k)

    # ---------- input ----------
    def key(self, k):
        if k == pygame.K_c and self.state in ("call", "play", "replay", "result", "over"):
            self.follow = not self.follow
            return
        if k == pygame.K_ESCAPE:
            if self.state in ("side", "over") and not WEB:   # in a browser there's nothing to quit to
                raise SystemExit
            self.state = "side"
            return
        if self.state == "side":
            if k in (pygame.K_o, pygame.K_1):
                self.side, self.state = "offense", "difficulty"
            elif k in (pygame.K_d, pygame.K_2):
                self.side, self.state = "defense", "difficulty"
        elif self.state == "difficulty":
            if k in KEYS_1_4 and KEYS_1_4[k] < 3:
                self.difficulty = DIFFICULTIES[KEYS_1_4[k]]
                self.new_drive()
        elif self.state == "call" and self.group is None:          # step 1: Run/Pass or Zone/Attack
            names = list(self.groups())
            letters = {pygame.key.key_code(n[0].lower()): i for i, n in enumerate(names)}
            if k in KEYS_1_4 and KEYS_1_4[k] < len(names):
                self.gchoice = KEYS_1_4[k]
                self.group, self.choice = names[self.gchoice], 0
            elif k in letters:
                self.gchoice = letters[k]
                self.group, self.choice = names[self.gchoice], 0
            elif k in (pygame.K_UP, pygame.K_LEFT, pygame.K_DOWN, pygame.K_RIGHT):
                self.gchoice = (self.gchoice + 1) % len(names)
            elif k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.group, self.choice = names[self.gchoice], 0
        elif self.state == "call":                                 # step 2: the play
            n = len(self.my_plays())
            if k in KEYS_1_4 and KEYS_1_4[k] < n:
                self.choice = KEYS_1_4[k]
            elif k in (pygame.K_UP, pygame.K_LEFT):
                self.choice = (self.choice - 1) % n
            elif k in (pygame.K_DOWN, pygame.K_RIGHT):
                self.choice = (self.choice + 1) % n
            elif k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.snap()
            elif k == pygame.K_BACKSPACE:
                self.group = None
        elif self.state == "play":
            if k in (pygame.K_SPACE, pygame.K_RETURN):
                self.t = self.scene.duration
        elif self.state == "replay":
            if k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_r):
                self.state = self.after
        elif k == pygame.K_r and self.state in ("result", "over"):
            self.start_replay()
        elif self.state == "result":
            if k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.state, self.group = "call", None
        elif self.state == "over":
            if k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.new_drive()
            elif k == pygame.K_n:
                self.state = "side"

    def go_menu(self):
        self.state = "side"

    def pick(self, i):
        """A tapped play card: the first tap highlights it (shows the routes), a second tap snaps."""
        if i == self.choice:
            self.snap()
        else:
            self.choice = i

    def tap(self, pos):
        """A finger or mouse press. Buttons/cards first; anywhere else works like Space."""
        for rect, action in reversed(self.taps):
            if rect.collidepoint(pos):
                action()
                return
        if self.state in ("play", "replay", "result"):
            self.key(pygame.K_SPACE)

    def press(self, k):
        return lambda: self.key(k)

    # ---------- drawing ----------
    def draw(self):
        s, f = self.screen, self.fonts
        s.fill(R.BG)
        self.taps = []
        if self.state == "side":
            return self.draw_menu("Pick your side", ["1 / O   Offense: drive 80 yards for a touchdown",
                                                     "2 / D   Defense: stop them on downs"])
        if self.state == "difficulty":
            return self.draw_menu(f"You play {self.side}. Pick a difficulty",
                                  ["1   Easy: the computer calls at random",
                                   "2   Medium: it plays the down and distance",
                                   "3   Hard: it also learns your habits"])
        if self.phone:
            self.full.fill(R.BG)
            self.draw_field(self.full)
            return self.draw_phone()
        self.button("Menu  (Esc)", self.go_menu, R.W // 2 - 60, 16)
        d = self.drive
        # top bar
        R.text(s, f.bold, "PlayCaller", (R.FX, 22), R.BLUE)
        R.text(s, f.body, f"You: {self.side.capitalize()}  ·  {self.difficulty}", (R.FX + 150, 24), R.DIM)
        R.text(s, f.bold, self.situation(), (R.W - R.FX - f.bold.size(self.situation())[0], 22))
        self.draw_field(s)
        if self.state == "replay":
            R.tag(s, f.bold, "REPLAY", R.YELLOW)
        elif self.state == "play" and self.speed() < 1:
            R.tag(s, f.bold, "SLOW-MO", R.DIM)
        # bottom panel
        top = R.FY + R.FIELD_H + 16
        R.panel(s, (R.FX, top, 120 * R.PPY, R.H - top - 16))
        cam = ("Full field  (C)" if self.follow else "Follow cam  (C)", self.press(pygame.K_c))
        if self.state == "call":
            self.draw_call(top)
        elif self.state == "replay":
            self.buttons([("End replay  (Space)", self.press(pygame.K_SPACE))], top)
            self.draw_calls_line(top + 16)
        elif self.state == "play":
            self.buttons([cam, ("Skip  (Space)", self.press(pygame.K_SPACE))], top)
            self.draw_calls_line(top + 16)
        elif self.state == "result":
            self.draw_result(top)
            self.buttons([cam, ("Replay  (R)", self.press(pygame.K_r)),
                          ("Next play  (Space)", self.press(pygame.K_SPACE))], top)
        elif self.state == "over":
            self.draw_result(top)
            won = (d.winner == self.side)
            msg = ("YOU WIN" if won else "YOU LOSE") + f": {d.reason}"
            R.banner(s, f.huge, msg, R.GREEN if won else R.RED)
            self.buttons([("New side  (N)", self.press(pygame.K_n)), ("Replay  (R)", self.press(pygame.K_r)),
                          ("Play again  (Enter)", self.press(pygame.K_RETURN))], top)

    def situation(self):
        return self.last[3] if self.state in ("play", "replay", "over") else self.drive.situation()

    def draw_field(self, s):
        """The field and players, drawn on s at full size (the normal screen, or phone mode's big canvas)."""
        f, d = self.fonts, self.drive
        if self.state in ("play", "replay", "result", "over"):
            live = self.state in ("play", "replay")
            follow = self.follow and not self.phone           # phone mode does its own cropping
            w = self.world if follow else s
            if follow:
                w.fill(R.BG)
            t = self.t if live else self.scene.duration
            # during the play the drive isn't updated yet, so the lines are the pre-snap ones
            R.field(w, f, self.scene.los, self.ltg if live else None)
            R.players(w, self.scene, t)
            R.effects(w, f, self.scene, t)
            if follow:
                R.camera(s, w, self.cam)
        else:
            R.field(s, f, d.spot, d.line_to_gain)
            if self.group is not None:      # a play is highlighted: show what it does
                play = self.my_plays()[self.choice]
                key = (play, d.spot)
                if self.preview is None or self.preview[0] != key:
                    self.preview = (key, *preview(play, self.side, d.spot))
                _, scene, cut, carrier_cut = self.preview
                R.players(s, scene, 0.0)
                R.routes(s, scene, "O" if self.side == "offense" else "D", cut,
                         holder_at_end(scene), carrier_cut)
            else:
                if self.formation is None or self.formation.los != d.spot:
                    self.formation = build(d.resolve(OFFENSE[0], DEFENSE[0], random.Random(0)),
                                           d.spot, random.Random(0))
                R.players(s, self.formation, 0.0)

    # ---------- phone mode (sideways phone: field left, panel right) ----------
    def draw_phone(self):
        s, f, d = self.screen, self.fonts, self.drive
        sw, sh = s.get_size()
        fw = sw - PANEL_W                                   # width of the field view
        field = pygame.Rect(R.FX, R.FY, 120 * R.PPY, R.FIELD_H)
        if self.follow:                                     # zoomed in: full field height, ~65 yards wide
            if self.state == "call":
                cx = R.to_px(d.spot + 10, 0)[0]             # line of scrimmage, a bit of room downfield
            else:
                cx = R.to_px(*self.cam)[0]
            view = pygame.Rect(0, 0, int(R.FIELD_H * fw / sh), R.FIELD_H)
            view.center = (int(cx), field.centery)
            view.clamp_ip(field)
            s.blit(pygame.transform.smoothscale(self.full.subsurface(view), (fw, sh)), (0, 0))
        else:                                               # whole field, shrunk to fit
            k = fw / field.width
            img = pygame.transform.smoothscale(self.full.subsurface(field), (fw, int(field.height * k)))
            s.blit(img, (0, (sh - img.get_height()) // 2))
        if self.state == "replay":
            R.tag(s, f.bold, "REPLAY", R.YELLOW, (10, 10))
        elif self.state == "play" and self.speed() < 1:
            R.tag(s, f.bold, "SLOW-MO", R.DIM, (10, 10))
        if self.state == "over":
            won = (d.winner == self.side)
            R.banner(s, f.big, "YOU WIN" if won else "YOU LOSE", R.GREEN if won else R.RED, (fw // 2, sh // 2))

        # side panel
        x0, inner = fw + 20, PANEL_W - 40
        R.panel(s, (fw + 8, 8, PANEL_W - 16, sh - 16))
        mw = f.body.size("Menu")[0] + 28
        sit = self.situation()
        sf = f.bold if f.bold.size(sit)[0] < inner - mw - 8 else f.body     # "4th & Goal on opp 10" etc.
        R.text(s, sf, sit, (x0, 18))
        R.text(s, f.small, f"You: {self.side.capitalize()}  ·  {self.difficulty}", (x0, 48), R.DIM)
        self.button("Menu", self.go_menu, fw + PANEL_W - 20 - mw, 16)
        y, bottom = 80, sh - 20 - 44                        # content area; a row of buttons below it
        cam = ("Full field" if self.follow else "Zoom in", self.press(pygame.K_c))
        if self.state == "call":
            if self.group is None:
                names = list(self.groups())
                R.text(s, f.small, "Pick a group", (x0, y), R.DIM)
                items = [(f"{n}", "  ·  ".join(self.groups()[n]), self.press(pygame.K_1 + i))
                         for i, n in enumerate(names)]
                sel = self.gchoice
                if self.last:
                    mine, cpu, res, _ = self.last
                    R.wrap(s, f.small, f"Last: you {mine}, CPU {cpu}: {res.describe()}", (x0, bottom - 6),
                           inner, R.DIM, 19)
                bottom -= 10
            else:
                R.text(s, f.small, f"{self.group}: tap a play, tap again to snap", (x0, y), R.DIM)
                items = [(n, DESCRIPTION[n], lambda i=i: self.pick(i)) for i, n in enumerate(self.my_plays())]
                sel = self.choice
                self.phone_buttons([("Back", self.press(pygame.K_BACKSPACE)),
                                    ("Snap", self.press(pygame.K_RETURN))])
            y += 26
            gap = 6
            h = min(110, (bottom - y - gap * (len(items) - 1)) // len(items))
            for i, (title, sub, action) in enumerate(items):
                rect = pygame.Rect(x0 - 6, y + i * (h + gap), inner + 12, h)
                self.taps.append((rect, action))
                pygame.draw.rect(s, (52, 59, 88) if i == sel else R.BG, rect, border_radius=6)
                if i == sel:
                    pygame.draw.rect(s, R.BLUE, rect, 2, border_radius=6)
                R.text(s, f.bold, title, (x0 + 4, rect.y + 4), R.BLUE if i == sel else R.TEXT)
                s.set_clip(rect.inflate(0, -4))
                R.wrap(s, f.small, sub, (x0 + 4, rect.y + 34), inner - 8, R.DIM, 19)
                s.set_clip(None)
            return
        mine, cpu, res, _ = self.last
        R.text(s, f.bold, f"You: {mine}", (x0, y), R.BLUE if self.side == "offense" else R.RED)
        R.text(s, f.bold, f"CPU: {cpu}", (x0, y + 32), R.RED if self.side == "offense" else R.BLUE)
        if self.state in ("result", "over"):
            R.wrap(s, f.bold, res.describe(), (x0, y + 80), inner, R.YELLOW, 30)
            edge = {1: "Offense had the edge", 0: "Even matchup", -1: "Defense had the edge"}[res.edge]
            R.text(s, f.small, edge, (x0, y + 146), R.DIM)
        if self.state == "over":
            R.wrap(s, f.small, d.reason, (x0, y + 172), inner, R.DIM, 19)
            self.phone_buttons([("New side", self.press(pygame.K_n)), ("Replay", self.press(pygame.K_r)),
                                ("Again", self.press(pygame.K_RETURN))])
        elif self.state == "result":
            self.phone_buttons([cam, ("Replay", self.press(pygame.K_r)), ("Next", self.press(pygame.K_SPACE))])
        elif self.state == "play":
            self.phone_buttons([cam, ("Skip", self.press(pygame.K_SPACE))])
        elif self.state == "replay":
            self.phone_buttons([("End replay", self.press(pygame.K_SPACE))])

    def phone_buttons(self, items):
        """Equal-width buttons across the bottom of the phone panel."""
        sw, sh = self.screen.get_size()
        gap, inner = 8, PANEL_W - 40
        w = (inner - gap * (len(items) - 1)) // len(items)
        for i, (label, action) in enumerate(items):
            self.button(label, action, sw - PANEL_W + 20 + i * (w + gap), sh - 20 - 40, w)

    def hint(self, s, top):
        f = self.fonts.body
        R.text(self.screen, f, s, (R.FX + 120 * R.PPY - 20 - f.size(s)[0], top + 16), R.DIM)

    def button(self, label, action, x, y, w=None):
        """A pill you can tap or click (also shows the key for it). Returns its width."""
        f = self.fonts.body
        rect = pygame.Rect(x, y, w or f.size(label)[0] + 28, 40 if self.phone else 36)
        pygame.draw.rect(self.screen, R.BG, rect, border_radius=18)
        pygame.draw.rect(self.screen, R.DIM, rect, 1, border_radius=18)
        R.text(self.screen, f, label, rect.center, R.TEXT, center=True)
        self.taps.append((rect.inflate(8, 12), action))   # a little bigger than drawn: easier with a finger
        return rect.width

    def buttons(self, items, top):
        """A row of buttons, right-aligned in the bottom panel."""
        f = self.fonts.body
        x = R.FX + 120 * R.PPY - 20
        for label, action in reversed(items):
            x -= f.size(label)[0] + 28
            self.button(label, action, x, top + 10)
            x -= 12

    def draw_menu(self, title, lines):
        s, f = self.screen, self.fonts
        cx, sh = s.get_width() // 2, s.get_height()
        ys = (60, 110, 165, 210) if self.phone else (170, 230, 330, 392)   # logo, tagline, title, rows
        R.text(s, f.huge, "PlayCaller", (cx, ys[0]), R.BLUE, center=True)
        R.text(s, f.body, "One drive. Touchdown or nothing.", (cx, ys[1]), R.DIM, center=True)
        R.text(s, f.big, title, (cx, ys[2]), R.TEXT, center=True)
        for i, line in enumerate(lines):           # each line is a tappable row
            rect = pygame.Rect(cx - 320, ys[3] + i * 60, 640, 52)
            pygame.draw.rect(s, R.PANEL, rect, border_radius=8)
            R.text(s, f.bold, line, (cx - 300, rect.y + 11), R.TEXT)
            self.taps.append((rect, self.press(pygame.K_1 + i)))
        if not self.phone:
            R.text(s, f.small, "Tap a line or press its key" + ("" if WEB else "  ·  Esc: quit"),
                   (cx, sh - 40), R.DIM, center=True)
        R.text(s, f.small, f"build {BUILD}  ·  {'phone' if self.phone else 'normal'} layout  ·  {SCREEN_INFO}",
               (cx, sh - 16), R.DIM, center=True)

    def card(self, x, top, w, sel, title, sub, action):
        s, f = self.screen, self.fonts
        rect = (x - 8, top + 44, w, 84)
        self.taps.append((pygame.Rect(rect), action))
        pygame.draw.rect(s, (52, 59, 88) if sel else R.BG, rect, border_radius=6)
        if sel:
            pygame.draw.rect(s, R.BLUE, rect, 2, border_radius=6)
        R.text(s, f.bold, title, (x, top + 52), R.BLUE if sel else R.TEXT)
        R.wrap(s, f.small, sub, (x, top + 84), w - 16, R.DIM, 19)

    def columns(self, n):
        """Card positions for n cards across the panel: (x of card i, card width)."""
        gap, inner = 16, 120 * R.PPY - 40
        w = (inner - gap * (n - 1)) // n
        return (lambda i: R.FX + 20 + i * (w + gap)), w

    def draw_call(self, top):
        s, f = self.screen, self.fonts
        what = "play" if self.side == "offense" else "defense"
        if self.group is None:
            names = list(self.groups())
            keys = " / ".join(n[0] for n in names)
            R.text(s, f.body, f"Call your {what}: tap a group   (or 1–{len(names)} / {keys}, arrows + Enter)",
                   (R.FX + 20, top + 12), R.DIM)
            x, w = self.columns(len(names))
            for i, name in enumerate(names):
                self.card(x(i), top, w, i == self.gchoice,
                          f"{i + 1}  {name}", "  ·  ".join(self.groups()[name]), self.press(pygame.K_1 + i))
        else:
            plays = self.my_plays()
            R.text(s, f.body, f"{self.group}: pick the {what}   (tap twice to snap, or 1–{len(plays)} / arrows)",
                   (R.FX + 20, top + 12), R.DIM)
            self.buttons([("Back  (Bksp)", self.press(pygame.K_BACKSPACE)),
                          ("Snap  (Enter)", self.press(pygame.K_RETURN))], top - 2)
            x, w = self.columns(len(plays))
            for i, name in enumerate(plays):
                self.card(x(i), top, w, i == self.choice, f"{i + 1}  {name}", DESCRIPTION[name],
                          lambda i=i: self.pick(i))
        if self.last and self.group is None:
            mine, cpu, res, _ = self.last
            self.hint(f"Last: you {mine}, CPU {cpu}: {res.describe()}", top - 4)

    def draw_calls_line(self, y):
        s, f = self.screen, self.fonts
        mine, cpu, _, _ = self.last
        R.text(s, f.bold, f"You: {mine}", (R.FX + 20, y), R.BLUE if self.side == "offense" else R.RED)
        R.text(s, f.bold, f"CPU: {cpu}", (R.FX + 380, y), R.RED if self.side == "offense" else R.BLUE)

    def draw_result(self, top):
        s, f = self.screen, self.fonts
        mine, cpu, res, _ = self.last
        self.draw_calls_line(top + 16)
        edge = {1: "Offense had the edge", 0: "Even matchup", -1: "Defense had the edge"}[res.edge]
        R.text(s, f.bold, res.describe(), (R.FX + 20, top + 56), R.YELLOW)
        R.text(s, f.body, edge, (R.FX + 20, top + 88), R.DIM)

    # ---------- loop ----------
    async def run(self):
        while True:
            dt = self.clock.tick(60) / 1000
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return
                try:
                    if e.type == pygame.KEYDOWN:
                        self.key(e.key)
                    elif e.type == pygame.FINGERDOWN:        # touch screen (tablet/phone browser)
                        self.tap((e.x * self.screen.get_width(), e.y * self.screen.get_height()))
                    elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and not getattr(e, "touch", False):
                        self.tap(e.pos)                      # real mouse (touches already came as FINGERDOWN)
                except SystemExit:
                    return
            if self.state in ("play", "replay", "result", "over"):
                self.update_camera(dt)
            if self.state == "replay":                 # half speed, slower still at the big moment
                self.t += dt * (0.5 if self.speed() == 1 else 0.25)
                if self.t >= self.scene.duration:
                    self.state = self.after
            if self.state == "play":
                self.t += dt * self.speed()
                if self.t >= self.scene.duration:
                    self.finish_play()
            self.draw()
            pygame.display.flip()
            await asyncio.sleep(0)       # lets the browser breathe (web build); harmless on desktop


async def amain():
    await Game().run()
    pygame.quit()


def main():
    asyncio.run(amain())


if __name__ == "__main__":
    main()
