"""PlayCaller: pick a side, pick a difficulty, call plays, watch them run."""

if __package__ in (None, ""):          # started as a file (py main.py inside playcaller/)
    import pathlib
    import sys
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
    __package__ = "playcaller"
    import playcaller  # noqa: F401  (sets up the package before the relative imports)

import asyncio
import random
import sys
import pygame

from . import render as R
from .ai import Computer, DIFFICULTIES
from .anim import build, preview, holder_at_end
from .engine import Drive
from .plays import OFFENSE, DEFENSE, OFFENSE_GROUPS, DEFENSE_GROUPS, DESCRIPTION

WEB = sys.platform == "emscripten"   # running in a browser (pygbag)

KEYS_1_4 = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
            pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3}


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("PlayCaller")
        self.screen = pygame.display.set_mode((R.W, R.H))
        self.fonts = R.Fonts()
        self.clock = pygame.time.Clock()
        self.rng = random.Random()
        self.state = "side"
        self.side = None            # the side YOU play
        self.difficulty = None
        self.choice = 0             # play within the open group
        self.group = None           # None = picking a group; else the group's name
        self.gchoice = 0            # highlighted group
        self.drive = None
        self.cpu = None
        self.scene = None
        self.t = 0.0
        self.last = None            # (your call, cpu call, result)
        self.preview = None
        self.formation = None
        self.moments = []           # times of the big moments in the current play (slow motion)
        self.ltg = None
        self.after = None           # the state a replay returns to
        self.follow = True          # camera follows the ball during plays (C toggles)
        self.cam = (0.0, 0.0)       # camera center, yards
        # the field is drawn here, then the camera crops it. 24-bit on purpose: a copy of the display
        # format can carry an alpha channel, and then everything drawn on it comes out invisible
        self.world = pygame.Surface((R.W, R.H), 0, 24)

    # ---------- flow ----------
    def new_drive(self):
        self.drive = Drive()
        cpu_side = "defense" if self.side == "offense" else "offense"
        self.cpu = Computer(self.difficulty, cpu_side, self.rng)
        self.choice, self.last, self.state = 0, None, "call"
        self.group, self.gchoice = None, 0
        self.preview = None

    def groups(self) -> dict:
        return OFFENSE_GROUPS if self.side == "offense" else DEFENSE_GROUPS

    def my_plays(self):
        return self.groups()[self.group]

    def snap(self):
        d = self.drive
        mine = self.my_plays()[self.choice]
        cpu = self.cpu.call(d.down, d.to_go)
        self.cpu.observe(d.down, d.to_go, mine)
        off, de = (mine, cpu) if self.side == "offense" else (cpu, mine)
        result = d.resolve(off, de, self.rng)
        self.scene = build(result, d.spot, self.rng)
        self.last = (mine, cpu, result, d.situation())
        self.t, self.state = 0.0, "play"
        self.cam = R.camera_target(self.scene, 0.0)
        self.ltg = d.line_to_gain                # pre-snap line to gain, for the replay
        big = {"int", "sack", "fumble", "td"}
        self.moments = [e[0] for e in self.scene.events
                        if e[1] in big or (e[1] == "catch" and result.yards >= 15)]

    def speed(self):
        """1.0 normally; slow motion for about a second around the play's big moment."""
        for te in self.moments:
            if -0.35 < self.t - te < 0.6:
                return 0.3
        return 1.0

    def start_replay(self):
        self.after, self.state = self.state, "replay"
        # start just before the big moment (whole play if there wasn't one)
        self.t = max(0.0, self.moments[0] - 1.5) if self.moments else 0.0
        self.cam = R.camera_target(self.scene, self.t)

    def finish_play(self):
        self.drive.apply(self.last[2])
        self.state = "over" if self.drive.over else "result"

    def update_camera(self, dt):
        if self.scene is None:
            return
        t = self.t if self.state in ("play", "replay") else self.scene.duration
        tx, ty = R.camera_target(self.scene, t)
        k = min(1.0, dt * 4.0)                  # ease toward the ball, no jerky jumps
        self.cam = (self.cam[0] + (tx - self.cam[0]) * k, self.cam[1] + (ty - self.cam[1]) * k)

    # ---------- input ----------
    def key(self, k):
        if k == pygame.K_c and self.state in ("call", "play", "replay", "result", "over"):
            self.follow = not self.follow
            return
        if k == pygame.K_ESCAPE:
            if self.state in ("side", "over") and not WEB:   # in a browser there's nothing to quit to
                raise SystemExit
            self.state = "side"
            return
        if self.state == "side":
            if k in (pygame.K_o, pygame.K_1):
                self.side, self.state = "offense", "difficulty"
            elif k in (pygame.K_d, pygame.K_2):
                self.side, self.state = "defense", "difficulty"
        elif self.state == "difficulty":
            if k in KEYS_1_4 and KEYS_1_4[k] < 3:
                self.difficulty = DIFFICULTIES[KEYS_1_4[k]]
                self.new_drive()
        elif self.state == "call" and self.group is None:          # step 1: Run/Pass or Zone/Attack
            names = list(self.groups())
            letters = {pygame.key.key_code(n[0].lower()): i for i, n in enumerate(names)}
            if k in KEYS_1_4 and KEYS_1_4[k] < len(names):
                self.gchoice = KEYS_1_4[k]
                self.group, self.choice = names[self.gchoice], 0
            elif k in letters:
                self.gchoice = letters[k]
                self.group, self.choice = names[self.gchoice], 0
            elif k in (pygame.K_UP, pygame.K_LEFT, pygame.K_DOWN, pygame.K_RIGHT):
                self.gchoice = (self.gchoice + 1) % len(names)
            elif k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.group, self.choice = names[self.gchoice], 0
        elif self.state == "call":                                 # step 2: the play
            n = len(self.my_plays())
            if k in KEYS_1_4 and KEYS_1_4[k] < n:
                self.choice = KEYS_1_4[k]
            elif k in (pygame.K_UP, pygame.K_LEFT):
                self.choice = (self.choice - 1) % n
            elif k in (pygame.K_DOWN, pygame.K_RIGHT):
                self.choice = (self.choice + 1) % n
            elif k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.snap()
            elif k == pygame.K_BACKSPACE:
                self.group = None
        elif self.state == "play":
            if k in (pygame.K_SPACE, pygame.K_RETURN):
                self.t = self.scene.duration
        elif self.state == "replay":
            if k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_r):
                self.state = self.after
        elif k == pygame.K_r and self.state in ("result", "over"):
            self.start_replay()
        elif self.state == "result":
            if k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.state, self.group = "call", None
        elif self.state == "over":
            if k in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.new_drive()
            elif k == pygame.K_n:
                self.state = "side"

    # ---------- drawing ----------
    def draw(self):
        s, f = self.screen, self.fonts
        s.fill(R.BG)
        if self.state == "side":
            return self.draw_menu("Pick your side", ["1 / O   Offense: drive 80 yards for a touchdown",
                                                     "2 / D   Defense: stop them on downs"])
        if self.state == "difficulty":
            return self.draw_menu(f"You play {self.side}. Pick a difficulty",
                                  ["1   Easy: the computer calls at random",
                                   "2   Medium: it plays the down and distance",
                                   "3   Hard: it also learns your habits"])
        d = self.drive
        # top bar
        R.text(s, f.bold, "PlayCaller", (R.FX, 22), R.BLUE)
        R.text(s, f.body, f"You: {self.side.capitalize()}  ·  {self.difficulty}", (R.FX + 150, 24), R.DIM)
        sit = self.last[3] if self.state in ("play", "replay", "over") else d.situation()
        R.text(s, f.bold, sit, (R.W - R.FX - f.bold.size(sit)[0], 22))
        # field + players
        if self.state in ("play", "replay", "result", "over"):
            live = self.state in ("play", "replay")
            w = self.world if self.follow else s
            if self.follow:
                w.fill(R.BG)
            t = self.t if live else self.scene.duration
            # during the play the drive isn't updated yet, so the lines are the pre-snap ones
            R.field(w, f, self.scene.los, self.ltg if live else None)
            R.players(w, self.scene, t)
            R.effects(w, f, self.scene, t)
            if self.follow:
                R.camera(s, w, self.cam)
            if self.state == "replay":
                R.tag(s, f.bold, "REPLAY", R.YELLOW)
            elif self.state == "play" and self.speed() < 1:
                R.tag(s, f.bold, "SLOW-MO", R.DIM)
        else:
            R.field(s, f, d.spot, d.line_to_gain)
            if self.group is not None:      # a play is highlighted: show what it does
                play = self.my_plays()[self.choice]
                key = (play, d.spot)
                if self.preview is None or self.preview[0] != key:
                    self.preview = (key, *preview(play, self.side, d.spot))
                _, scene, cut, carrier_cut = self.preview
                R.players(s, scene, 0.0)
                R.routes(s, scene, "O" if self.side == "offense" else "D", cut,
                         holder_at_end(scene), carrier_cut)
            else:
                if self.formation is None or self.formation.los != d.spot:
                    self.formation = build(d.resolve(OFFENSE[0], DEFENSE[0], random.Random(0)),
                                           d.spot, random.Random(0))
                R.players(s, self.formation, 0.0)
        # bottom panel
        top = R.FY + R.FIELD_H + 16
        R.panel(s, (R.FX, top, 120 * R.PPY, R.H - top - 16))
        if self.state == "call":
            self.draw_call(top)
        elif self.state == "replay":
            self.hint("Space: end replay", top)
            self.draw_calls_line(top + 16)
        elif self.state == "play":
            self.hint("Space: skip  ·  C: " + ("full field" if self.follow else "follow cam"), top)
            self.draw_calls_line(top + 16)
        elif self.state == "result":
            self.draw_result(top)
            self.hint("Space: next play  ·  R: replay", top)
        elif self.state == "over":
            self.draw_result(top)
            won = (d.winner == self.side)
            msg = ("YOU WIN" if won else "YOU LOSE") + f": {d.reason}"
            R.banner(s, f.huge, msg, R.GREEN if won else R.RED)
            self.hint("Enter: play again  ·  R: replay  ·  N or Esc: new side/difficulty" if WEB else
                      "Enter: play again  ·  R: replay  ·  N: new side/difficulty  ·  Esc: quit", top)

    def hint(self, s, top):
        f = self.fonts.body
        R.text(self.screen, f, s, (R.FX + 120 * R.PPY - 20 - f.size(s)[0], top + 16), R.DIM)

    def draw_menu(self, title, lines):
        s, f = self.screen, self.fonts
        R.text(s, f.huge, "PlayCaller", (R.W // 2, 170), R.BLUE, center=True)
        R.text(s, f.body, "One drive. Touchdown or nothing.", (R.W // 2, 230), R.DIM, center=True)
        R.text(s, f.big, title, (R.W // 2, 330), R.TEXT, center=True)
        for i, line in enumerate(lines):
            R.text(s, f.bold, line, (R.W // 2 - 300, 400 + i * 50), R.TEXT)
        if not WEB:
            R.text(s, f.small, "Esc: quit", (R.W // 2, R.H - 40), R.DIM, center=True)

    def card(self, x, top, w, sel, title, sub):
        s, f = self.screen, self.fonts
        rect = (x - 8, top + 44, w, 84)
        pygame.draw.rect(s, (52, 59, 88) if sel else R.BG, rect, border_radius=6)
        if sel:
            pygame.draw.rect(s, R.BLUE, rect, 2, border_radius=6)
        R.text(s, f.bold, title, (x, top + 52), R.BLUE if sel else R.TEXT)
        R.wrap(s, f.small, sub, (x, top + 84), w - 16, R.DIM, 19)

    def columns(self, n):
        """Card positions for n cards across the panel: (x of card i, card width)."""
        gap, inner = 16, 120 * R.PPY - 40
        w = (inner - gap * (n - 1)) // n
        return (lambda i: R.FX + 20 + i * (w + gap)), w

    def draw_call(self, top):
        s, f = self.screen, self.fonts
        what = "play" if self.side == "offense" else "defense"
        if self.group is None:
            names = list(self.groups())
            keys = " / ".join(n[0] for n in names)
            R.text(s, f.body, f"Call your {what}: pick a group   (1–{len(names)} or {keys}, arrows + Enter)",
                   (R.FX + 20, top + 12), R.DIM)
            x, w = self.columns(len(names))
            for i, name in enumerate(names):
                self.card(x(i), top, w, i == self.gchoice,
                          f"{i + 1}  {name}", "  ·  ".join(self.groups()[name]))
        else:
            plays = self.my_plays()
            R.text(s, f.body, f"{self.group}: pick the {what}   (1–{len(plays)} or arrows, Enter to snap, "
                   "Backspace: back)", (R.FX + 20, top + 12), R.DIM)
            x, w = self.columns(len(plays))
            for i, name in enumerate(plays):
                self.card(x(i), top, w, i == self.choice, f"{i + 1}  {name}", DESCRIPTION[name])
        if self.last and self.group is None:
            mine, cpu, res, _ = self.last
            self.hint(f"Last: you {mine}, CPU {cpu}: {res.describe()}", top - 4)

    def draw_calls_line(self, y):
        s, f = self.screen, self.fonts
        mine, cpu, _, _ = self.last
        R.text(s, f.bold, f"You: {mine}", (R.FX + 20, y), R.BLUE if self.side == "offense" else R.RED)
        R.text(s, f.bold, f"CPU: {cpu}", (R.FX + 380, y), R.RED if self.side == "offense" else R.BLUE)

    def draw_result(self, top):
        s, f = self.screen, self.fonts
        mine, cpu, res, _ = self.last
        self.draw_calls_line(top + 16)
        edge = {1: "Offense had the edge", 0: "Even matchup", -1: "Defense had the edge"}[res.edge]
        R.text(s, f.bold, res.describe(), (R.FX + 20, top + 56), R.YELLOW)
        R.text(s, f.body, edge, (R.FX + 20, top + 88), R.DIM)

    # ---------- loop ----------
    async def run(self):
        while True:
            dt = self.clock.tick(60) / 1000
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return
                if e.type == pygame.KEYDOWN:
                    try:
                        self.key(e.key)
                    except SystemExit:
                        return
            if self.state in ("play", "replay", "result", "over"):
                self.update_camera(dt)
            if self.state == "replay":                 # half speed, slower still at the big moment
                self.t += dt * (0.5 if self.speed() == 1 else 0.25)
                if self.t >= self.scene.duration:
                    self.state = self.after
            if self.state == "play":
                self.t += dt * self.speed()
                if self.t >= self.scene.duration:
                    self.finish_play()
            self.draw()
            pygame.display.flip()
            await asyncio.sleep(0)       # lets the browser breathe (web build); harmless on desktop


async def amain():
    await Game().run()
    pygame.quit()


def main():
    asyncio.run(amain())


if __name__ == "__main__":
    main()
