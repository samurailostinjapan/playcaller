"""Turns a resolved play into movement: where every player and the ball is at time t.

The result is decided first (engine.py); this module scripts 22 players so the
play on screen matches it. Coordinates are in yards: x = yards from the
offense's own goal line (offense always drives to the right), y = 0..53.3
across the field.
"""

from dataclasses import dataclass
import math
import random

from .engine import Result

WIDTH = 160 / 3          # 53.3 yards
MID = WIDTH / 2
SPEED = 7.5              # ball carrier yards per second after the catch/handoff


def _smooth(u: float) -> float:
    return u * u * (3 - 2 * u)


class Path:
    """Keyframes (t, x, y); position eases between them and holds after the last."""

    def __init__(self, t, x, y):
        self.keys = [(t, max(-9.5, min(109.5, x)), y)]

    def to(self, t, x, y):
        if t <= self.keys[-1][0]:
            t = self.keys[-1][0] + 0.01
        x = max(-9.5, min(109.5, x))          # stay inside the end zones
        self.keys.append((t, x, y))
        return self

    def hold(self, t):
        _, x, y = self.keys[-1]
        return self.to(t, x, y)

    @property
    def end(self):
        return self.keys[-1][1], self.keys[-1][2]

    def at(self, t):
        k = self.keys
        if t <= k[0][0]:
            return k[0][1], k[0][2]
        for (t0, x0, y0), (t1, x1, y1) in zip(k, k[1:]):
            if t <= t1:
                u = _smooth((t - t0) / (t1 - t0))
                return x0 + (x1 - x0) * u, y0 + (y1 - y0) * u
        return k[-1][1], k[-1][2]


@dataclass
class Player:
    team: str      # "O" or "D"
    role: str      # QB, RB, WR, TE, OL, DL, LB, CB, S
    path: Path


@dataclass
class Ball:
    """Who has the ball when. Segments: ("hold", path, t0, t1) or ("air", (x0,y0), (x1,y1), t0, t1)."""
    segments: list

    def at(self, t):
        for seg in self.segments:
            if seg[0] == "hold" and t <= seg[3]:
                return (*seg[1].at(t), 0.0)
            if seg[0] == "air" and t <= seg[4]:
                _, (x0, y0), (x1, y1), t0, t1 = seg
                u = max(0.0, (t - t0) / (t1 - t0))
                height = math.sin(math.pi * u) * min(1.0, math.dist((x0, y0), (x1, y1)) / 25)
                return x0 + (x1 - x0) * u, y0 + (y1 - y0) * u, height
        last = self.segments[-1]
        if last[0] == "hold":
            return (*last[1].at(t), 0.0)
        return (*last[2], 0.0)


@dataclass
class Scene:
    players: list
    ball: Ball
    duration: float
    los: float
    end_spot: float


def _clampy(y):
    return max(1.0, min(WIDTH - 1.0, y))


def build(r: Result, spot: int, rng: random.Random) -> Scene:
    L, C = float(spot), MID
    side = rng.choice((-1, 1))         # which side runs/screens/deep shots go to
    O, D = [], []

    def add(lst, team, role, x, y):
        p = Player(team, role, Path(0.0, x, _clampy(y)))
        lst.append(p)
        return p

    # ---- offense formation ----
    ol = [add(O, "O", "OL", L - 0.6, C + dy) for dy in (-4, -2, 0, 2, 4)]
    te = add(O, "O", "TE", L - 0.8, C + 6 * side)
    qb = add(O, "O", "QB", L - 1.3, C)
    rb = add(O, "O", "RB", L - 6.0, C)
    wr_far = add(O, "O", "WR", L - 0.8, C + 20 * side)      # the deep target
    wr_near = add(O, "O", "WR", L - 0.8, C - 20 * side)
    slot = add(O, "O", "WR", L - 1.5, C - 12 * side)

    # ---- defense formation ----
    dp = r.defense_play
    dl = [add(D, "D", "DL", L + 1.0, C + dy) for dy in (-5, -1.8, 1.8, 5)]
    lb_x = {"Run Stuff": 3.5, "Prevent": 9.0}.get(dp, 5.0)
    lbs = [add(D, "D", "LB", L + lb_x, C + dy) for dy in (-4, 0, 4)]
    cb_x = {"Man": 2.0, "Cover 3": 7.0, "Prevent": 11.0}.get(dp, 6.0)
    cb_far = add(D, "D", "CB", L + cb_x, C + 20 * side)
    cb_near = add(D, "D", "CB", L + cb_x, C - 20 * side)
    if dp == "Cover 2":
        s_far = add(D, "D", "S", L + 14, C + 11 * side)
        s_near = add(D, "D", "S", L + 14, C - 11 * side)
    elif dp == "Cover 3":
        s_far = add(D, "D", "S", L + 15, C)                    # deep middle third
        s_near = add(D, "D", "S", L + 7, C - 8 * side)         # robber underneath
    elif dp == "Prevent":
        s_far = add(D, "D", "S", L + 22, C + 10 * side)
        s_near = add(D, "D", "S", L + 22, C - 10 * side)
    elif dp == "Run Stuff":
        s_far = add(D, "D", "S", L + 6, C + 7 * side)          # the eighth man in the box
        s_near = add(D, "D", "S", L + 14, C)
    elif dp == "Man":
        s_far = add(D, "D", "S", L + 15, C)                    # single high
        s_near = add(D, "D", "S", L + 6, C - 12 * side)        # on the slot
    else:  # Zone Blitz
        s_far = add(D, "D", "S", L + 13, C + 9 * side)
        s_near = add(D, "D", "S", L + 13, C - 9 * side)

    run = r.offense_play in ("Inside Run", "Outside Run", "Draw")
    passing = not run
    yards = float(r.yards)

    # ---- the ball carrier's story ----
    t_event = 0.0          # handoff / catch time
    ball = []
    carrier = None
    end: tuple[float, float] | None = None   # final ball spot
    tackled = r.kind in ("run", "catch", "sack", "fumble") and spot + r.yards < 100

    qb.path.to(0.3, L - 2.0, C)
    if r.offense_play == "Inside Run":
        hole = C + rng.choice((-1, 1)) * 1.0
        rb.path.to(0.7, L - 2.5, C)
        qb.path.to(0.9, L - 3.5, C - side * 2)               # carry out the fake
        rb.path.to(1.1, L - 0.3, hole)
        t_event = 0.7
        end = (L + yards, _clampy(hole + rng.uniform(-3, 3) + (yards > 10) * side * rng.uniform(0, 6)))
        carrier = rb
    elif r.offense_play == "Outside Run":
        qb.path.to(0.6, L - 2.5, C)
        rb.path.to(0.6, L - 4.0, C + side * 3)
        rb.path.to(1.3, L - 2.0, C + side * 12)
        if yards > -2:
            rb.path.to(1.7, L + 0.5, C + side * 15)
        t_event = 0.6
        end = (L + yards, _clampy(C + side * (16 + min(yards, 8) * 0.3)))
        carrier = rb
    elif r.offense_play == "Draw":
        qb.path.to(0.9, L - 4.5, C)                          # sells the drop-back
        rb.path.to(0.5, L - 5.5, C + 1.2)                    # sets up like a pass blocker
        rb.path.to(1.05, L - 4.8, C + 0.6)                   # delayed handoff
        hole = C + rng.choice((-1, 1)) * 1.0
        rb.path.to(1.6, L - 0.3, hole)
        t_event = 1.05
        end = (L + yards, _clampy(hole + rng.uniform(-3, 3) + (yards > 10) * side * rng.uniform(0, 6)))
        carrier = rb
    elif r.offense_play == "Quick Slants":
        qb.path.to(0.6, L - 4.0, C)                          # three-step drop
        tgt = rng.choice((wr_far, wr_near, slot))
        carrier = tgt
    elif r.offense_play == "Screen":
        qb.path.to(1.1, L - 7.0, C)
        rb.path.to(0.5, L - 5.0, C)
        rb.path.to(1.3, L - 3.0, C + side * 10)
        t_event = 1.55
        end = (L + yards, _clampy(C + side * 12))
        carrier = rb
    else:  # Play-Action Deep
        rb.path.to(0.6, L - 2.5, C)                          # the fake
        rb.path.to(1.4, L - 2.5, C + side * 3)               # stays in to block
        qb.path.to(0.6, L - 2.5, C)
        qb.path.to(1.6, L - 8.0, C)
        # four deep options: outside go, post to the middle, slot seam, TE corner
        tgt, route = rng.choices([(wr_far, "go"), (wr_near, "post"), (slot, "seam"), (te, "corner")],
                                 weights=[35, 25, 25, 15])[0]
        carrier = tgt

    # ---- events, ball and end time ----
    if r.kind == "sack":
        sacker = dl[2 if side > 0 else 1]
        t_sack = 2.0
        qb.path.to(t_sack, L - 8.0, C).to(t_sack + 0.5, L + yards, C + rng.uniform(-1, 1))
        sacker.path.to(t_sack, L - 7.0, C + 0.6).to(t_sack + 0.5, L + yards + 0.6, C + 0.5)
        end = qb.path.end
        ball = [("hold", qb.path, 0, 99)]
        duration = t_sack + 0.8
        carrier = qb
    elif r.offense_play == "Play-Action Deep":
        if r.kind == "catch":   # long gains = catch around 25-45 yards out, then run after the catch
            depth = r.yards if r.yards <= 45 else rng.randint(28, 45)
        else:
            depth = rng.randint(22, 38)
        depth = min(depth, 100 - L + 6)   # near the goal line the shot goes to the end zone
        sx, sy = tgt.path.end
        target = {
            "go":     (L + depth, sy),                                 # straight down the sideline
            "post":   (L + depth, C + (sy - C) * 0.2),                 # breaks toward the middle
            "seam":   (L + depth, sy + (C - sy) * 0.15),               # straight up the hash
            "corner": (L + depth * 0.85, _clampy(sy + side * 14)),     # breaks to the sideline
        }[route]
        target = (target[0], _clampy(target[1]))
        tgt.path.to(1.3, L + min(12, depth * 0.4), sy)               # stem: sell the route
        t_throw = 2.3
        flight = 0.6 + depth / 30
        t_event = t_throw + flight
        tgt.path.to(t_event, *target)
        start = qb.path.at(t_throw)
        ball = [("hold", qb.path, 0, t_throw), ("air", start, target, t_throw, t_event)]
        cover = sorted((cb_far, cb_near, s_far, s_near), key=lambda d: math.dist(d.path.at(0), target))[:2]
        toward_mid = 1 if target[1] < C else -1
        if r.kind == "catch":
            end = (L + yards, _clampy(target[1] + rng.uniform(-4, 4)))
            run_time = math.dist(target, end) / SPEED
            tgt.path.to(t_event + run_time, *end)
            ball.append(("hold", tgt.path, t_event, 99))
            duration = t_event + run_time + 0.6
        elif r.kind == "interception":
            picker = cover[0]
            picker.path.to(t_event, target[0] + 0.5, _clampy(target[1] + toward_mid * 0.8))
            back = (target[0] - rng.uniform(5, 15), _clampy(target[1] + toward_mid * rng.uniform(2, 8)))
            picker.path.to(t_event + 1.5, *back)
            ball.append(("hold", picker.path, t_event, 99))
            end, carrier, tackled = back, picker, False
            duration = t_event + 2.0
        else:  # incomplete
            landing = (target[0] + rng.uniform(1, 4), _clampy(target[1] - toward_mid * rng.uniform(1, 3)))
            ball[-1] = ("air", start, landing, t_throw, t_event)
            ball.append(("hold", Path(t_event, *landing), t_event, 99))
            end, tackled = None, False
            duration = t_event + 0.8
        # coverage reacts to the deep ball
        beaten = r.kind == "catch" and r.yards > depth      # receiver got behind them
        for d, k in zip(cover, (1.0, 1.6)):
            if d.path.keys[-1][0] >= t_event:      # already moving to make the interception
                continue
            if beaten:
                d.path.to(t_event, target[0] - 2.5 * k, _clampy(target[1] + toward_mid * 2 * k))
            else:
                d.path.to(t_event, target[0] + k, _clampy(target[1] + toward_mid * k))
    elif r.offense_play == "Quick Slants":
        sx, sy = tgt.path.end
        inward = 1 if sy < C else -1
        tgt.path.to(0.6, L + 4.5, sy)                        # stem
        depth = min(6.5, r.yards - 0.5) if r.kind == "catch" else 6.5
        target = (L + max(depth, 0.5), _clampy(sy + inward * 5))
        t_throw, t_event = 0.85, 1.2
        tgt.path.to(t_event, *target)
        start = qb.path.at(t_throw)
        ball = [("hold", qb.path, 0, t_throw), ("air", start, target, t_throw, t_event)]
        cover = sorted(lbs + [cb_far, cb_near, s_far, s_near], key=lambda d: math.dist(d.path.at(0), target))[:2]
        if r.kind == "catch":
            end = (L + yards, _clampy(target[1] + inward * rng.uniform(0, 6)))
            run_time = max(0.3, math.dist(target, end) / SPEED)
            tgt.path.to(t_event + run_time, *end)
            ball.append(("hold", tgt.path, t_event, 99))
            duration = t_event + run_time + 0.6
        elif r.kind == "interception":
            picker = cover[0]
            picker.path.to(t_event, target[0] + 0.6, target[1])
            back = (target[0] - rng.uniform(4, 12), _clampy(target[1] - inward * rng.uniform(2, 6)))
            picker.path.to(t_event + 1.4, *back)
            ball.append(("hold", picker.path, t_event, 99))
            end, carrier, tackled = back, picker, False
            duration = t_event + 1.9
        else:  # incomplete
            landing = (target[0] + rng.uniform(1, 3), _clampy(target[1] + inward * rng.uniform(1, 2)))
            ball[-1] = ("air", start, landing, t_throw, t_event)
            ball.append(("hold", Path(t_event, *landing), t_event, 99))
            end, tackled = None, False
            duration = t_event + 0.8
        for d, k in zip(cover, (0.8, 1.4)):                  # closest defenders break on the ball
            if d.path.keys[-1][0] < t_event:
                d.path.to(t_event, target[0] + k, _clampy(target[1] - inward * k))
    elif r.offense_play == "Screen":
        if r.kind == "incomplete":
            landing = (L - 2.0, _clampy(C + side * 12))
            ball = [("hold", qb.path, 0, 1.2), ("air", qb.path.at(1.2), landing, 1.2, t_event),
                    ("hold", Path(t_event, *landing), t_event, 99)]
            end, tackled = None, False
            duration = t_event + 0.8
        elif r.kind == "interception":
            picker = lbs[0 if side < 0 else 2]
            catch_pt = (L - 2.5, _clampy(C + side * 9))
            picker.path.to(t_event, *catch_pt)
            back = (catch_pt[0] - rng.uniform(4, 12), _clampy(catch_pt[1] + side * 3))
            picker.path.to(t_event + 1.4, *back)
            ball = [("hold", qb.path, 0, 1.2), ("air", qb.path.at(1.2), catch_pt, 1.2, t_event),
                    ("hold", picker.path, t_event, 99)]
            end, carrier, tackled = back, picker, False
            duration = t_event + 1.9
        else:
            assert end is not None
            run_time = math.dist(rb.path.end, end) / SPEED
            rb.path.to(t_event + run_time, *end)
            ball = [("hold", qb.path, 0, 1.2), ("air", qb.path.at(1.2), rb.path.at(t_event), 1.2, t_event),
                    ("hold", rb.path, t_event, 99)]
            duration = t_event + run_time + 0.6
    else:  # runs (incl. fumble)
        assert end is not None
        start = rb.path.end
        run_time = max(0.4, math.dist(start, end) / SPEED)
        t_end = rb.path.keys[-1][0] + run_time
        rb.path.to(t_end, *end)
        ball = [("hold", qb.path, 0, t_event), ("hold", rb.path, t_event, 99)]
        duration = t_end + 0.6
        if r.kind == "fumble":
            loose = (end[0] + rng.uniform(-1, 2), _clampy(end[1] + rng.uniform(-2, 2)))
            ball = [("hold", qb.path, 0, t_event), ("hold", rb.path, t_event, t_end),
                    ("air", end, loose, t_end, t_end + 0.4), ("hold", Path(t_end + 0.4, *loose), t_end + 0.4, 99)]
            duration = t_end + 1.2

    t_end = duration - 0.6

    # ---- everyone else ----
    if run:
        te.path.to(1.0, L + 1.5, te.path.end[1] + side * 0.5)
        for w in (wr_far, wr_near, slot):
            w.path.to(1.4, w.path.end[0] + 6, w.path.end[1])        # block downfield
    else:
        def free(p):          # not already running the targeted route
            return p.path.keys[-1][0] < 0.5
        if free(te):
            te.path.to(1.2, L + 4, te.path.end[1]).to(2.4, L + 9, te.path.end[1] - side * 3)
        if free(wr_far):
            wr_far.path.to(2.2, L + 18, wr_far.path.end[1])
        if free(wr_near):
            wr_near.path.to(1.6, L + 12, wr_near.path.end[1]).to(2.6, L + 14, wr_near.path.end[1] + side * 6)
        if free(slot):
            slot.path.to(1.4, L + 8, slot.path.end[1]).to(2.6, L + 10, slot.path.end[1] + side * 10)

    # defense before the event: rush, cover, drop
    rushers = list(dl)
    if dp == "Zone Blitz":
        dropper = dl[0]
        dropper.path.to(1.2, L + 5, dropper.path.end[1] - 2)
        rushers = dl[1:] + [lbs[2 if side < 0 else 0]]
    if dp == "Run Stuff":
        rushers = dl + [lbs[1]]
    # ---- the line battle: each lineman engages a rusher, both keep moving ----
    if run:
        t_block = min(t_end, max(t_event + 1.0, 1.8))
        won = r.edge >= 0 and r.yards >= 2                  # did the line open a hole?
        push = 1.8 if won else -0.6                         # yards the line moves forward by 1.0s
        def line_x(tt):
            return L - 0.6 + min(1.0, tt / 1.0) * push + (max(0.0, tt - 1.0) * 0.8 if won else 0.0)
        lean = side * 0.8 if r.offense_play == "Outside Run" else 0.0
    else:
        t_block = {"Screen": 0.9, "Quick Slants": min(t_end, 1.3)}.get(
            r.offense_play, 2.0 if r.kind == "sack" else min(t_end, 2.6))
        def line_x(tt):                                     # set back, then the pocket slowly gives
            return L - 0.6 - min(1.0, tt / 0.6) * 1.4 - max(0.0, tt - 0.6) * 0.6
        lean = 0.0
    dl_rushing = [d for d in dl if d in rushers and d.path.keys[-1][0] < 0.5]
    pairs, used = [], set()
    for d in dl_rushing:                                    # each rusher gets the closest lineman
        o = min((o for o in ol if id(o) not in used), key=lambda o: abs(o.path.end[1] - d.path.end[1]))
        pairs.append((d, o))
        used.add(id(o))
    for i, o in enumerate(ol):
        base = o.path.end[1]
        tt, k = 0.0, 0
        while tt < t_block - 1e-6:
            tt = min(t_block, tt + 0.3)
            wob = 0.35 * math.sin(k * 1.9 + i)              # hand fighting
            o.path.to(tt, line_x(tt), _clampy(base + lean * min(1.0, tt) + wob))
            k += 1
    for d, o in pairs:                                      # rusher stays in the blocker's face
        for (tt, ox, oy) in o.path.keys[1:]:
            d.path.to(tt, ox + 0.9, _clampy(oy + (0.3 if d.path.end[1] > oy else -0.3)))
    for p in rushers:
        if p.path.keys[-1][0] < 0.5:
            p.path.to(1.0, L - 1.5 if passing else L - 0.5, p.path.end[1] * 0.7 + C * 0.3)
    for lb in lbs:
        if lb.path.keys[-1][0] < 0.5 and lb not in rushers:
            if passing:
                lb.path.to(1.2, L + (14 if dp == "Prevent" else 8), lb.path.end[1])
            else:
                lb.path.to(1.0, L + 2, lb.path.end[1] * 0.6 + C * 0.4)
    if dp == "Man":
        for d, w, off in ((cb_far, wr_far, -side), (cb_near, wr_near, side), (s_near, slot, 0)):
            if d.path.keys[-1][0] < 0.5:      # not already reacting to a throw
                wx, wy = w.path.at(2.2)
                d.path.to(2.2, wx + 1, _clampy(wy + off))
    else:
        for cb in (cb_far, cb_near):
            if cb.path.keys[-1][0] < 0.5:
                deep = {"Cover 2": 5, "Prevent": 18}.get(dp, 12)
                cb.path.to(1.5, L + deep, cb.path.end[1] * 0.85 + C * 0.15)
    for s in (s_far, s_near):
        if s.path.keys[-1][0] < 0.5:
            s.path.to(1.6, s.path.end[0] + (2 if passing else -3), s.path.end[1] * 0.8 + C * 0.2)

    # defense after the event: converge on the ball carrier (or ball)
    if end is not None and carrier is not None and carrier.team == "O":
        chasers = sorted(D, key=lambda p: math.dist(p.path.end, end))
        for i, p in enumerate(chasers):
            if p.path.keys[-1][0] >= t_end:
                continue
            ang = rng.uniform(0, math.tau)
            if tackled:
                dist = 0.9 if i == 0 else 1.5 + i * 0.9
                t_arrive = t_end if i < 3 else t_end + 0.5
            else:   # touchdown: they trail the runner
                dist = 3 + i * 1.5
                t_arrive = t_end + 0.3
            x = end[0] - abs(math.cos(ang)) * dist if not tackled else end[0] + math.cos(ang) * dist
            p.path.to(max(t_arrive, p.path.keys[-1][0] + 0.3), x, _clampy(end[1] + math.sin(ang) * dist))
    elif end is not None and carrier is not None and carrier.team == "D":
        # interception: closest offensive players chase the defender, the rest turn and pursue
        for i, p in enumerate(sorted(O, key=lambda p: math.dist(p.path.end, end))):
            if p.path.keys[-1][0] >= t_end:
                continue
            if i < 4:
                p.path.to(t_end + 0.2, end[0] + 1.5 + i, _clampy(end[1] + (i - 1.5) * 1.5))
            else:
                px, py = p.path.end
                frac = 0.5 if p.role in ("WR", "TE", "RB") else 0.25
                p.path.to(t_end + 0.2, px + (end[0] - px) * frac, _clampy(py + (end[1] - py) * frac))

    # offense after the event: keep playing until the whistle
    follow = {"OL": 0.35, "QB": 0.2, "RB": 0.55, "TE": 0.65, "WR": 0.8}
    for p in O:
        if p is carrier or p.path.keys[-1][0] >= t_end:
            continue
        px, py = p.path.end
        if end is not None and carrier is not None and carrier.team == "O":
            # escort the ball carrier: blockers flow toward him, faster players get further
            gain = end[0] - L
            frac = follow[p.role] * (1.0 if gain > 4 else 0.4)
            tx = px + (end[0] - px) * frac
            ty = py + (end[1] - py) * frac * 0.7
            if p.role in ("WR", "TE") and gain > 15:      # lead blockers stay a step ahead
                tx = max(tx, min(end[0] - rng.uniform(2, 6), 109.0))
            p.path.to(t_end, tx, _clampy(ty))
        elif end is None:
            # incomplete: receivers ease off at the end of the route, line holds
            drift = 3.0 if p.role in ("WR", "TE") else 0.5
            p.path.to(t_end + 0.3, px + drift, py)
    return Scene(O + D, Ball(ball), duration, L, end[0] if end else L)
