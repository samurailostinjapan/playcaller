"""PlayCaller. Quiet pygame's startup banner and the AVX2 build warning."""
import os
import warnings

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
warnings.filterwarnings("ignore", message=".*avx2.*", category=RuntimeWarning)
