"""Play definitions, groups and the matchup grid (see PLAYBOOK.md)."""

# The play-caller first picks a group, then a play in it.
OFFENSE_GROUPS = {
    "Run":  ["Inside Run", "Outside Run", "Draw"],
    "Pass": ["Screen", "Quick Slants", "Play-Action Deep"],
}
DEFENSE_GROUPS = {
    "Zone":   ["Cover 2", "Cover 3", "Prevent"],
    "Attack": ["Man", "Zone Blitz", "Run Stuff"],
}

OFFENSE = [p for plays in OFFENSE_GROUPS.values() for p in plays]
DEFENSE = [p for plays in DEFENSE_GROUPS.values() for p in plays]

RUNS = set(OFFENSE_GROUPS["Run"])

# +1 = offense has the edge, -1 = defense has the edge, 0 = even.
GRID = {
    #                     Cover 2   Cover 3   Man      Zone Blitz  Run Stuff  Prevent
    "Inside Run":       {"Cover 2": +1, "Cover 3": 0,  "Man": -1, "Zone Blitz": 0,  "Run Stuff": -1, "Prevent": +1},
    "Outside Run":      {"Cover 2": 0,  "Cover 3": 0,  "Man": +1, "Zone Blitz": +1, "Run Stuff": -1, "Prevent": 0},
    "Draw":             {"Cover 2": +1, "Cover 3": 0,  "Man": 0,  "Zone Blitz": +1, "Run Stuff": -1, "Prevent": +1},
    "Screen":           {"Cover 2": 0,  "Cover 3": 0,  "Man": -1, "Zone Blitz": +1, "Run Stuff": +1, "Prevent": 0},
    "Quick Slants":     {"Cover 2": -1, "Cover 3": +1, "Man": 0,  "Zone Blitz": -1, "Run Stuff": +1, "Prevent": +1},
    "Play-Action Deep": {"Cover 2": -1, "Cover 3": -1, "Man": +1, "Zone Blitz": -1, "Run Stuff": +1, "Prevent": -1},
}

DESCRIPTION = {
    "Inside Run": "RB hits the gap between the tackles",
    "Outside Run": "RB runs wide and tries to turn the corner",
    "Draw": "Looks like a pass, then a delayed handoff up the middle",
    "Screen": "Let the rush in, dump it to the RB behind blockers",
    "Quick Slants": "Three-step drop, quick throw to a receiver cutting inside",
    "Play-Action Deep": "Fake the run, throw deep",
    "Cover 2": "Two deep safeties, corners own the edge and the flats",
    "Cover 3": "Three deep, four underneath, solid against the run",
    "Prevent": "Everyone deep: no big play, but gives up the short stuff",
    "Man": "Man coverage, one deep safety, extra man near the line",
    "Zone Blitz": "Blitz from one spot, a lineman drops into coverage",
    "Run Stuff": "Eight in the box, built to stop the run",
}


def edge(offense_play: str, defense_play: str) -> int:
    return GRID[offense_play][defense_play]
