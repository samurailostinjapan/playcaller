"""Play definitions and the matchup grid (see PLAYBOOK.md)."""

OFFENSE = ["Inside Run", "Outside Run", "Screen", "Play-Action Deep"]
DEFENSE = ["Cover 2", "Man", "Zone Blitz", "Run Stuff"]

RUNS = {"Inside Run", "Outside Run"}

# +1 = offense has the edge, -1 = defense has the edge, 0 = even.
GRID = {
    "Inside Run":       {"Cover 2": +1, "Man": -1, "Zone Blitz": 0,  "Run Stuff": -1},
    "Outside Run":      {"Cover 2": -1, "Man": +1, "Zone Blitz": +1, "Run Stuff": -1},
    "Screen":           {"Cover 2": 0,  "Man": -1, "Zone Blitz": +1, "Run Stuff": +1},
    "Play-Action Deep": {"Cover 2": -1, "Man": +1, "Zone Blitz": -1, "Run Stuff": +1},
}

DESCRIPTION = {
    "Inside Run": "RB hits the gap between the tackles",
    "Outside Run": "RB runs wide and tries to turn the corner",
    "Screen": "Let the rush in, dump it to the RB behind blockers",
    "Play-Action Deep": "Fake the run, throw deep",
    "Cover 2": "Zone, two deep safeties, corners own the edge",
    "Man": "Man coverage, one deep safety, extra man near the line",
    "Zone Blitz": "Blitz from one spot, a lineman drops into coverage",
    "Run Stuff": "Eight in the box, built to stop the run",
}


def edge(offense_play: str, defense_play: str) -> int:
    return GRID[offense_play][defense_play]
