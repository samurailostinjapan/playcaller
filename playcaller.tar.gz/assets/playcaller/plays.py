"""Play definitions, groups and the matchup grid (see PLAYBOOK.md)."""

# The play-caller first picks a group, then a play in it.
OFFENSE_GROUPS = {
    "Run":   ["Inside Run", "Outside Run", "Draw", "QB Sneak"],
    "Short": ["Screen", "Quick Slants", "Flats", "Crossers"],
    "Deep":  ["Play-Action Deep", "Four Verticals"],
}
DEFENSE_GROUPS = {
    "Zone":   ["Cover 2", "Cover 3", "Prevent"],
    "Attack": ["Man", "Cover 0 Blitz", "Zone Blitz", "Run Stuff"],
}

OFFENSE = [p for plays in OFFENSE_GROUPS.values() for p in plays]
DEFENSE = [p for plays in DEFENSE_GROUPS.values() for p in plays]

RUNS = set(OFFENSE_GROUPS["Run"])

# +1 = offense has the edge, -1 = defense has the edge, 0 = even.
_COLS = ["Cover 2", "Cover 3", "Prevent", "Man", "Cover 0 Blitz", "Zone Blitz", "Run Stuff"]
_ROWS = {
    #                    C2  C3  Prev Man  C0  ZBlz RunS
    "Inside Run":       (+1,  0, +1, -1, -1,  0, -1),
    "Outside Run":      ( 0, +1,  0,  0, -1, +1, -1),
    "Draw":             ( 0, -1, +1,  0, +1, +1, -1),
    "QB Sneak":         (+1,  0, +1,  0, -1,  0, -1),
    "Screen":           ( 0, -1, -1, -1, +1, +1, +1),
    "Quick Slants":     (-1, +1, +1,  0,  0, -1, +1),
    "Flats":            (-1, +1, +1, -1, +1,  0, +1),
    "Crossers":         ( 0,  0, -1, +1, +1,  0,  0),
    "Play-Action Deep": (-1, -1, -1, +1, -1, -1, +1),
    "Four Verticals":   (+1, +1, -1, +1, -1, -1,  0),
}
GRID = {o: dict(zip(_COLS, row)) for o, row in _ROWS.items()}

DESCRIPTION = {
    "Inside Run": "RB hits the gap between the tackles",
    "Outside Run": "RB runs wide to turn the corner",
    "Draw": "Fake a pass, then a delayed handoff",
    "QB Sneak": "QB pushes behind the center: 1-2 yards",
    "Screen": "Let the rush in, dump it to the RB",
    "Quick Slants": "Quick throw to a receiver cutting inside",
    "Flats": "Short out to the sideline",
    "Crossers": "Receivers cross the middle",
    "Play-Action Deep": "Fake the run, throw deep",
    "Four Verticals": "Four receivers straight downfield",
    "Cover 2": "Two deep safeties, corners own the flats",
    "Cover 3": "Three deep, four under, solid vs the run",
    "Prevent": "Everyone deep: gives up short stuff",
    "Man": "Man coverage, one deep safety",
    "Cover 0 Blitz": "Send everyone, man up, nobody deep",
    "Zone Blitz": "Blitz from one spot, a lineman drops",
    "Run Stuff": "Eight in the box to stop the run",
}


def edge(offense_play: str, defense_play: str) -> int:
    return GRID[offense_play][defense_play]
