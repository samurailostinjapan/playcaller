"""Drawing: field, players, ball, and the text panels. Tokyo Night Storm for the UI."""

import os
import pygame

from .anim import WIDTH as FIELD_W

W, H = 1280, 780
PPY = 10                      # pixels per yard
FX, FY = 40, 78               # top-left of the field (x = -10 yards)
FIELD_H = int(FIELD_W * PPY)

BG = (31, 35, 53)             # #1f2335
PANEL = (36, 40, 59)          # #24283b
TEXT = (192, 202, 245)        # #c0caf5
DIM = (115, 122, 162)         # #737aa2
BLUE = (122, 162, 247)        # #7aa2f7
RED = (247, 118, 142)         # #f7768e
YELLOW = (224, 175, 104)      # #e0af68
GREEN = (158, 206, 106)       # #9ece6a
GRASS_A = (46, 112, 58)
GRASS_B = (52, 122, 64)
ENDZONE = (30, 84, 44)
LINE = (235, 240, 235)
BALL = (139, 90, 43)

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_FONT_FILES = [os.path.join(_ASSETS, "NotoSans-Regular.ttf"), os.path.join(_ASSETS, "NotoSans-Bold.ttf")]
# Noto Sans is bundled (SIL Open Font License, assets/OFL-NotoSans.txt) so the web build has it too.


class Fonts:
    def __init__(self):
        def load(path, size):
            return pygame.font.Font(path if os.path.exists(path) else None, size)
        self.small = load(_FONT_FILES[0], 16)
        self.body = load(_FONT_FILES[0], 20)
        self.bold = load(_FONT_FILES[1], 22)
        self.big = load(_FONT_FILES[1], 40)
        self.huge = load(_FONT_FILES[1], 64)
        self.num = load(_FONT_FILES[1], 22)


def to_px(x, y):
    return FX + (x + 10) * PPY, FY + y * PPY


def text(surf, font, s, pos, color=TEXT, center=False):
    img = font.render(s, True, color)
    rect = img.get_rect()
    if center:
        rect.center = pos
    else:
        rect.topleft = pos
    surf.blit(img, rect)
    return rect


def field(surf, fonts, los=None, line_to_gain=None):
    # grass stripes every 5 yards, end zones at both ends
    for i in range(20):
        x0, _ = to_px(i * 5, 0)
        pygame.draw.rect(surf, GRASS_A if i % 2 else GRASS_B, (x0, FY, 5 * PPY, FIELD_H))
    for ez in (-10, 100):
        x0, _ = to_px(ez, 0)
        pygame.draw.rect(surf, ENDZONE, (x0, FY, 10 * PPY, FIELD_H))
    # yard lines + numbers
    for yd in range(0, 101, 5):
        x, _ = to_px(yd, 0)
        pygame.draw.line(surf, LINE, (x, FY), (x, FY + FIELD_H), 3 if yd in (0, 100) else 1)
        if yd % 10 == 0 and 0 < yd < 100:
            n = str(yd if yd <= 50 else 100 - yd)
            for yy in (FY + 40, FY + FIELD_H - 40):
                text(surf, fonts.num, n, (x, yy), (230, 236, 230), center=True)
    # hash marks
    for yd in range(1, 100):
        x, _ = to_px(yd, 0)
        for hy in (FIELD_W / 2 - 3.1, FIELD_W / 2 + 3.1, 1, FIELD_W - 1):
            _, py = to_px(0, hy)
            pygame.draw.line(surf, LINE, (x, py - 3), (x, py + 3), 1)
    pygame.draw.rect(surf, LINE, (FX, FY, 120 * PPY, FIELD_H), 2)
    # end zone labels
    for ez, label in ((-5, "OWN"), (105, "SCORE")):
        x, y = to_px(ez, FIELD_W / 2)
        img = pygame.transform.rotate(fonts.bold.render(label, True, (200, 220, 200)), 90)
        surf.blit(img, img.get_rect(center=(x, y)))
    if los is not None:
        x, _ = to_px(los, 0)
        pygame.draw.line(surf, BLUE, (x, FY), (x, FY + FIELD_H), 3)
    if line_to_gain is not None and line_to_gain < 100:
        x, _ = to_px(line_to_gain, 0)
        pygame.draw.line(surf, YELLOW, (x, FY), (x, FY + FIELD_H), 3)


def players(surf, scene, t):
    for p in sorted(scene.players, key=lambda p: p.team == "O"):   # offense on top
        x, y = p.path.at(t)
        px, py = to_px(x, y)
        color = BLUE if p.team == "O" else RED
        pygame.draw.circle(surf, (20, 22, 34), (px + 1, py + 2), 8)
        pygame.draw.circle(surf, color, (px, py), 8)
        pygame.draw.circle(surf, (20, 22, 34), (px, py), 8, 2)
    bx, by, h = scene.ball.at(t)
    px, py = to_px(bx, by)
    lift = h * 18
    pygame.draw.ellipse(surf, (20, 30, 20), (px - 4, py - 2, 8, 5))                     # shadow
    size = 6 + h * 4
    pygame.draw.ellipse(surf, BALL, (px - size, py - lift - size * 0.6, size * 2, size * 1.2))
    pygame.draw.ellipse(surf, (240, 230, 210), (px - size, py - lift - size * 0.6, size * 2, size * 1.2), 1)


def formation_preview(surf, scene):
    players(surf, scene, 0.0)


def panel(surf, rect):
    pygame.draw.rect(surf, PANEL, rect, border_radius=8)


def wrap(surf, font, s, pos, width, color=TEXT, line_h=None):
    words, line, y = s.split(), "", pos[1]
    line_h = line_h or font.get_linesize()
    for w in words:
        trial = (line + " " + w).strip()
        if font.size(trial)[0] > width and line:
            text(surf, font, line, (pos[0], y), color)
            line, y = w, y + line_h
        else:
            line = trial
    if line:
        text(surf, font, line, (pos[0], y), color)


def banner(surf, font, s, color):
    img = font.render(s, True, color)
    rect = img.get_rect(center=(W // 2, FY + FIELD_H // 2))
    box = pygame.Surface((rect.width + 60, rect.height + 30), pygame.SRCALPHA)
    box.fill((31, 35, 53, 225))
    surf.blit(box, box.get_rect(center=rect.center))
    surf.blit(img, rect)
