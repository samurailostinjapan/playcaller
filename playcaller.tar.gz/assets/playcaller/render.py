"""Drawing: field, players, ball, and the text panels. Tokyo Night Storm for the UI."""

import math
import os
import random
import pygame

from .anim import WIDTH as FIELD_W

W, H = 1280, 780
PPY = 10                      # pixels per yard
FX, FY = 40, 78               # top-left of the field (x = -10 yards)
FIELD_H = int(FIELD_W * PPY)

BG = (31, 35, 53)             # #1f2335
PANEL = (36, 40, 59)          # #24283b
TEXT = (192, 202, 245)        # #c0caf5
DIM = (115, 122, 162)         # #737aa2
BLUE = (122, 162, 247)        # #7aa2f7
RED = (247, 118, 142)         # #f7768e
YELLOW = (224, 175, 104)      # #e0af68
GREEN = (158, 206, 106)       # #9ece6a
GRASS_A = (46, 112, 58)
GRASS_B = (52, 122, 64)
ENDZONE = (30, 84, 44)
LINE = (235, 240, 235)
BALL = (139, 90, 43)

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_FONT_FILES = [os.path.join(_ASSETS, "NotoSans-Regular.ttf"), os.path.join(_ASSETS, "NotoSans-Bold.ttf")]
# Noto Sans is bundled (SIL Open Font License, assets/OFL-NotoSans.txt) so the web build has it too.


class Fonts:
    def __init__(self):
        def load(path, size):
            return pygame.font.Font(path if os.path.exists(path) else None, size)
        self.small = load(_FONT_FILES[0], 16)
        self.body = load(_FONT_FILES[0], 20)
        self.bold = load(_FONT_FILES[1], 22)
        self.big = load(_FONT_FILES[1], 40)
        self.huge = load(_FONT_FILES[1], 64)
        self.num = load(_FONT_FILES[1], 22)


def to_px(x, y):
    return FX + (x + 10) * PPY, FY + y * PPY


def text(surf, font, s, pos, color=TEXT, center=False):
    img = font.render(s, True, color)
    rect = img.get_rect()
    if center:
        rect.center = pos
    else:
        rect.topleft = pos
    surf.blit(img, rect)
    return rect


def field(surf, fonts, los=None, line_to_gain=None):
    # grass stripes every 5 yards, end zones at both ends
    for i in range(20):
        x0, _ = to_px(i * 5, 0)
        pygame.draw.rect(surf, GRASS_A if i % 2 else GRASS_B, (x0, FY, 5 * PPY, FIELD_H))
    for ez in (-10, 100):
        x0, _ = to_px(ez, 0)
        pygame.draw.rect(surf, ENDZONE, (x0, FY, 10 * PPY, FIELD_H))
    # yard lines + numbers
    for yd in range(0, 101, 5):
        x, _ = to_px(yd, 0)
        pygame.draw.line(surf, LINE, (x, FY), (x, FY + FIELD_H), 3 if yd in (0, 100) else 1)
        if yd % 10 == 0 and 0 < yd < 100:
            n = str(yd if yd <= 50 else 100 - yd)
            for yy in (FY + 40, FY + FIELD_H - 40):
                text(surf, fonts.num, n, (x, yy), (230, 236, 230), center=True)
    # hash marks
    for yd in range(1, 100):
        x, _ = to_px(yd, 0)
        for hy in (FIELD_W / 2 - 3.1, FIELD_W / 2 + 3.1, 1, FIELD_W - 1):
            _, py = to_px(0, hy)
            pygame.draw.line(surf, LINE, (x, py - 3), (x, py + 3), 1)
    pygame.draw.rect(surf, LINE, (FX, FY, 120 * PPY, FIELD_H), 2)
    # end zone labels
    for ez, label in ((-5, "OWN"), (105, "SCORE")):
        x, y = to_px(ez, FIELD_W / 2)
        img = pygame.transform.rotate(fonts.bold.render(label, True, (200, 220, 200)), 90)
        surf.blit(img, img.get_rect(center=(x, y)))
    if los is not None:
        x, _ = to_px(los, 0)
        pygame.draw.line(surf, BLUE, (x, FY), (x, FY + FIELD_H), 3)
    if line_to_gain is not None and line_to_gain < 100:
        x, _ = to_px(line_to_gain, 0)
        pygame.draw.line(surf, YELLOW, (x, FY), (x, FY + FIELD_H), 3)


# jersey numbers by position, handed out in formation order
NUMBERS = {"QB": [12], "RB": [28], "WR": [11, 81, 84], "TE": [87], "OL": [72, 64, 55, 66, 76],
           "DL": [91, 94, 97, 99], "LB": [52, 54, 56], "CB": [21, 24], "S": [31, 33]}
KIT = {   # jersey, helmet, number
    "O": (BLUE, (52, 78, 150), (245, 248, 255)),
    "D": (RED, (150, 48, 72), (255, 245, 248)),
}
OUTLINE = (20, 22, 34)
_num_cache = {}


def _facing(p, t):
    """Angle (radians) the player faces: where he's moving, or where he last moved,
    or downfield toward the other team if he hasn't moved yet."""
    for back in (0.05, 0.3):
        x0, y0 = p.path.at(max(0.0, t - back))
        x1, y1 = p.path.at(t + 0.05)
        if math.hypot(x1 - x0, y1 - y0) > 0.15:
            return math.atan2(y1 - y0, x1 - x0), math.hypot(x1 - x0, y1 - y0) / (back + 0.05)
    return (0.0 if p.team == "O" else math.pi), 0.0


def _figure(team, scale, ang, stride, down):
    """One top-down player: drawn at 2x facing right, then rotated and smoothly shrunk."""
    jersey, helmet, _ = KIT[team]
    ss = 2                                               # supersample for clean edges
    k = scale * ss
    size = int(52 * k)
    img = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size / 2
    if down:                                             # stretched out on the turf
        pygame.draw.ellipse(img, OUTLINE, (c - 15 * k, c - 7 * k, 26 * k, 14 * k))
        pygame.draw.ellipse(img, jersey, (c - 14 * k, c - 6 * k, 24 * k, 12 * k))
        pygame.draw.circle(img, OUTLINE, (c + 12 * k, c), 5.5 * k)
        pygame.draw.circle(img, helmet, (c + 12 * k, c), 4.5 * k)
    else:
        # feet: alternate forward/back while running
        for side in (-1, 1):
            fx = c - 1 * k + stride * side * 5 * k
            pygame.draw.ellipse(img, OUTLINE, (fx - 3.5 * k, c + side * 5 * k - 2.5 * k, 7 * k, 5 * k))
        # shoulder pads: wide across, shallower front-to-back
        pygame.draw.ellipse(img, OUTLINE, (c - 8 * k, c - 12.5 * k, 15 * k, 25 * k))
        pygame.draw.ellipse(img, jersey, (c - 7 * k, c - 11.5 * k, 13 * k, 23 * k))
        # helmet at the front edge, face mask pointing where he's going
        hx = c + 5 * k
        pygame.draw.circle(img, OUTLINE, (hx, c), 5.2 * k)
        pygame.draw.circle(img, helmet, (hx, c), 4.3 * k)
        pygame.draw.arc(img, (230, 230, 230), (hx - 4.3 * k, c - 4.3 * k, 8.6 * k, 8.6 * k),
                        -1.0, 1.0, max(2, int(1.4 * k)))
    return pygame.transform.rotozoom(img, -math.degrees(ang), 1 / ss)


def _number(team, n):
    key = (team, n)
    if key not in _num_cache:
        font = pygame.font.Font(_FONT_FILES[1] if os.path.exists(_FONT_FILES[1]) else None, 9)
        img = font.render(str(n), True, KIT[team][2])
        shade = font.render(str(n), True, OUTLINE)
        out = pygame.Surface((img.get_width() + 2, img.get_height() + 2), pygame.SRCALPHA)
        out.blit(shade, (1, 1))
        out.blit(img, (0, 0))
        _num_cache[key] = out
    return _num_cache[key]


def players(surf, scene, t):
    # who is on the ground (tackled / sacked), who leaps for a pick, who celebrates
    down, leap, party = {}, {}, {}
    for (te, kind, _, _, who) in getattr(scene, "events", []):
        if who is None:
            continue
        if kind == "tackle":
            down[id(who)] = te + 0.1
        elif kind == "sack":
            down[id(who)] = te + 0.45
        elif kind == "int":
            leap[id(who)] = te
        elif kind == "td":
            party[id(who)] = te
    numbers, seen = {}, {}
    for p in scene.players:
        i = seen.get((p.team, p.role), 0)
        seen[(p.team, p.role)] = i + 1
        pool = NUMBERS.get(p.role, [0])
        numbers[id(p)] = pool[i % len(pool)]
    for p in sorted(scene.players, key=lambda p: p.team == "O"):   # offense on top
        x, y = p.path.at(t)
        px, py = to_px(x, y)
        scale = 1.0
        if id(p) in leap and abs(t - leap[id(p)]) < 0.3:            # goes up for the ball
            scale *= 1 + 0.5 * math.cos(math.pi * (t - leap[id(p)]) / 0.6)
        if id(p) in party and t > party[id(p)]:                     # bounces in the end zone
            scale *= 1 + 0.18 * abs(math.sin((t - party[id(p)]) * 9))
        ang, speed = _facing(p, t)
        is_down = id(p) in down and t >= down[id(p)]
        stride = math.sin(t * 16 + id(p) % 7) * min(1.0, speed / 3) if speed > 0.5 else 0.0
        fig = _figure(p.team, scale, ang, stride, is_down)
        surf.blit(fig, fig.get_rect(center=(px, py)))
        if not is_down:
            num = _number(p.team, numbers[id(p)])
            # number sits on the shoulder pads, a touch behind the helmet
            nx, ny = px - math.cos(ang) * 3.5, py - math.sin(ang) * 3.5
            surf.blit(num, num.get_rect(center=(nx, ny)))
    ball(surf, scene, t)


def ball(surf, scene, t):
    """The ball: tucked when carried; in the air it rises with the throw, points where it's
    going, wobbles like a spiral, and leaves its shadow on the grass below."""
    bx, by, h = scene.ball.at(t)
    gx, gy = to_px(bx, by)
    if h <= 0.01:                                            # carried or on the ground
        pygame.draw.ellipse(surf, BALL, (gx - 5, gy - 3, 10, 6))
        pygame.draw.ellipse(surf, (240, 230, 210), (gx - 5, gy - 3, 10, 6), 1)
        return
    # shadow: smaller and fainter the higher the ball is
    sw = max(4, 10 - h * 3)
    shadow = pygame.Surface((24, 12), pygame.SRCALPHA)
    pygame.draw.ellipse(shadow, (10, 20, 10, int(150 - h * 50)), (12 - sw / 2, 6 - sw / 4, sw, sw / 2))
    surf.blit(shadow, (gx - 12, gy - 6))
    # heading from where the ball is a moment later
    nx, ny, nh = scene.ball.at(t + 0.03)
    px0, py0 = gx, gy - h * 22
    px1, py1 = to_px(nx, ny)
    py1 -= nh * 22
    ang = math.degrees(math.atan2(-(py1 - py0), px1 - px0))
    length = 14 + h * 4                                      # closer to the "camera" at the top of the arc
    spin = 1 + 0.18 * math.sin(t * 45)                       # spiral wobble
    img = pygame.Surface((int(length) + 4, 12), pygame.SRCALPHA)
    rect = (2, 6 - 3.5 * spin, length, 7 * spin)
    pygame.draw.ellipse(img, BALL, rect)
    pygame.draw.ellipse(img, (240, 230, 210), rect, 1)
    pygame.draw.line(img, (240, 230, 210), (2 + length * 0.42, 6), (2 + length * 0.58, 6), 1)   # laces
    img = pygame.transform.rotate(img, ang)
    surf.blit(img, img.get_rect(center=(px0, py0)))


ZOOM = 1.3


def camera_target(scene, t):
    """Where the camera wants to be: on the ball, a few yards ahead of it."""
    bx, by, _ = scene.ball.at(t)
    return bx + 4, by


def camera(screen, world, cam):
    """Crop the world around the camera center, zoom it to fill the field area."""
    vw, vh = int(120 * PPY / ZOOM), int(FIELD_H / ZOOM)
    cx, cy = to_px(*cam)
    view = pygame.Rect(0, 0, vw, vh)
    view.center = (int(cx), int(cy))
    view.clamp_ip(pygame.Rect(FX, FY, 120 * PPY, FIELD_H))
    screen.blit(pygame.transform.smoothscale(world.subsurface(view), (120 * PPY, FIELD_H)), (FX, FY))


POPUP = {"sack": ("SACK!", RED), "int": ("PICKED OFF!", RED), "fumble": ("FUMBLE!", RED),
         "td": ("TOUCHDOWN!", GREEN), "incomplete": ("INCOMPLETE", TEXT)}
CONFETTI = [BLUE, RED, YELLOW, GREEN, (187, 154, 247), (125, 207, 255)]


def effects(surf, fonts, scene, t):
    """Bursts, dust, confetti and pop-up words for the play's key moments."""
    layer = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    for (te, kind, x, y, who) in scene.events:
        age = t - te
        if age < 0 or age > 1.6:
            continue
        cx, cy = to_px(x, y)
        rng = random.Random(int(te * 1000) + len(kind))
        if kind in ("tackle", "sack", "fumble") and age < 0.6:      # impact ring + dust kicked up
            u = age / 0.6
            big = 1.5 if kind == "sack" else 1.0
            pygame.draw.circle(layer, (255, 255, 255, int(200 * (1 - u))), (cx, cy), 6 + 22 * big * u, 3)
            for i in range(10):
                ang = i / 10 * math.tau + rng.uniform(-0.3, 0.3)
                dist = (8 + rng.uniform(6, 18) * big) * math.sqrt(u)
                pygame.draw.circle(layer, (170, 150, 110, int(170 * (1 - u))),
                                   (cx + math.cos(ang) * dist, cy + math.sin(ang) * dist), 3 * (1 - u) + 1)
        if kind == "catch" and age < 0.3:                            # little flash at the hands
            pygame.draw.circle(layer, (255, 255, 255, int(220 * (1 - age / 0.3))), (cx, cy), 6 + 20 * age, 2)
        if kind == "int" and age < 0.5:
            pygame.draw.circle(layer, (*RED, int(220 * (1 - age / 0.5))), (cx, cy), 8 + 40 * age, 3)
        if kind == "td":                                             # confetti burst, then it drifts down
            for i in range(40):
                ang = rng.uniform(0, math.tau)
                speed = rng.uniform(30, 110)
                px = cx + math.cos(ang) * speed * min(age, 0.5) * 2
                py = cy + math.sin(ang) * speed * min(age, 0.5) * 2 + 40 * max(0.0, age - 0.5) ** 2 * 2
                c = CONFETTI[i % len(CONFETTI)]
                alpha = int(255 * max(0.0, 1 - age / 1.6))
                w = 3 + 2 * abs(math.sin(age * 12 + i))                # flutter
                pygame.draw.rect(layer, (*c, alpha), (px, py, w, 5))
        if kind in POPUP:                                            # word floats up and fades
            word, color = POPUP[kind]
            u = min(1.0, age / 1.2)
            alpha = int(255 * (1 - u ** 3))
            img = fonts.bold.render(word, True, color)
            shade = fonts.bold.render(word, True, (15, 17, 26))
            img.set_alpha(alpha)
            shade.set_alpha(alpha)
            rect = img.get_rect(center=(cx, cy - 22 - 28 * u))
            rect.clamp_ip(pygame.Rect(FX, FY, 120 * PPY, FIELD_H))
            for dx, dy in ((2, 2), (-1, 1), (1, -1)):              # dark edge so it reads on the grass
                layer.blit(shade, rect.move(dx, dy))
            layer.blit(img, rect)
    surf.blit(layer, (0, 0))


def routes(surf, scene, team, t_cut, carrier=None, carrier_cut=0.0):
    """Your call drawn as arrows: where each of your players goes until t_cut."""
    layer = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    color = (*(BLUE if team == "O" else RED), 200)
    for p in scene.players:
        if p.team != team or p.role in ("OL",):
            continue
        cut = carrier_cut if p is carrier else t_cut
        pts = []
        for i in range(int(cut / 0.05) + 1):
            pt = to_px(*p.path.at(i * 0.05))
            if not pts or math.dist(pts[-1], pt) > 2:
                pts.append(pt)
        if len(pts) < 2 or math.dist(pts[0], pts[-1]) < 12:   # barely moves: no arrow
            continue
        pygame.draw.lines(layer, color, False, pts, 3)
        (x0, y0), (x1, y1) = pts[-2], pts[-1]
        ang = math.atan2(y1 - y0, x1 - x0)
        head = [(x1 + 4 * math.cos(ang), y1 + 4 * math.sin(ang)),
                (x1 - 10 * math.cos(ang - 0.5), y1 - 10 * math.sin(ang - 0.5)),
                (x1 - 10 * math.cos(ang + 0.5), y1 - 10 * math.sin(ang + 0.5))]
        pygame.draw.polygon(layer, color, head)
    surf.blit(layer, (0, 0))


def panel(surf, rect):
    pygame.draw.rect(surf, PANEL, rect, border_radius=8)


def wrap(surf, font, s, pos, width, color=TEXT, line_h=None):
    words, line, y = s.split(), "", pos[1]
    line_h = line_h or font.get_linesize()
    for w in words:
        trial = (line + " " + w).strip()
        if font.size(trial)[0] > width and line:
            text(surf, font, line, (pos[0], y), color)
            line, y = w, y + line_h
        else:
            line = trial
    if line:
        text(surf, font, line, (pos[0], y), color)


def tag(surf, font, s, color, pos=(FX + 12, FY + 12)):
    """A small label in the field's top-left corner (REPLAY, SLOW-MO)."""
    img = font.render(s, True, color)
    box = pygame.Surface((img.get_width() + 20, img.get_height() + 8), pygame.SRCALPHA)
    box.fill((15, 17, 26, 190))
    box.blit(img, (10, 4))
    surf.blit(box, pos)


def banner(surf, font, s, color, center=(W // 2, FY + FIELD_H // 2)):
    img = font.render(s, True, color)
    rect = img.get_rect(center=center)
    box = pygame.Surface((rect.width + 60, rect.height + 30), pygame.SRCALPHA)
    box.fill((31, 35, 53, 225))
    surf.blit(box, box.get_rect(center=rect.center))
    surf.blit(img, rect)
