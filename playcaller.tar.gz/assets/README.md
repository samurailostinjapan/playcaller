# PlayCaller

**Play in your browser:** https://samurailostinjapan.github.io/playcaller/

A football play-calling game (working title chosen 2026-11-01).

A side project, built a little at a time. Decisions so far are in the Log at the bottom.

## The idea (2026-11-01)

A football game where **both sides call their own plays**, then **the players move according to the play** and the result comes out of how the two calls meet on the field.

## Play it

```
cd ~/PlayCaller
py main.py          # or: python -m playcaller
```

Needs `python-pygame` (pacman). Pick a side (1/O offense, 2/D defense), a difficulty (1–3), then call plays with 1–4 or the arrows and Enter to snap. Space skips the animation / goes to the next play. Esc goes back to the menu.

Tests: `python -m unittest` (rules, plus 1,500 random plays checked to stay on the field and end where the result says).

## Web build (no install for players)

Built with [pygbag](https://pypi.org/project/pygbag/) (installed in `~/.venvs/pygbag`, not system-wide):

```
~/.venvs/pygbag/bin/python -m pygbag --build --title PlayCaller ~/PlayCaller
~/.venvs/pygbag/bin/python -m pygbag ~/PlayCaller     # local test server: http://localhost:8000
```

Test with pygbag's own server, not a plain `http.server`: on localhost the page fetches pygame from `/cdn/...`, which only pygbag's server proxies. `build/web/` (index.html, playcaller.apk, favicon.png) is the whole website. The browser downloads a WebAssembly Python + pygame from pygbag's CDN the first time, then runs the game. Noto Sans is bundled (SIL OFL, `playcaller/assets/OFL-NotoSans.txt`).

**Publish:** `./publish-web.sh` builds with pygbag and pushes `build/web` to the GitHub Pages repo (github.com/samurailostinjapan/playcaller). That repo only holds the built site; the code lives here on GitLab.

## Code

- `playcaller/plays.py`: the four plays per side and the matchup grid
- `playcaller/engine.py`: drive rules (downs, touchdown, safety, turnovers) and how a play's result is decided
- `playcaller/ai.py`: the computer's calls (Easy random, Medium situational, Hard also learns your habits)
- `playcaller/anim.py`: turns a result into 22 moving players + the ball
- `playcaller/render.py`, `playcaller/main.py`: the Pygame window, screens and input

## How it works

1. **Call:** offense picks formation + play (routes, run direction, blocking); defense picks front + coverage (man, zone, blitz). Both lock in without seeing the other.
2. **Snap:** players follow their assignments — receivers run routes, linemen block, defenders cover or rush.
3. **Resolve:** matchups decide the outcome (blitz gets home? receiver open? hole there?), with player ratings and some randomness.
4. **Result:** yards, down and distance, then the next call.

The hard and fun part is step 2: 22 players moving believably from simple rules. A top-down 2D field with simple figures to start.

## Open questions

- Matchup grid in PLAYBOOK.md: does it feel right?
- Depth: a few simple plays and quick drives, or a real playbook with custom plays and ratings?

## Later (parked)

- Rosters / team strength (preset teams or build-your-own).

## Log

- 2026-11-01: idea, folder created.
- 2026-11-01: American football. Modes: player vs computer and player vs player. Python desktop app with Pygame (`python-pygame` from extra; not installed yet).
- 2026-11-01: two-player dropped. Player vs computer only, with difficulty levels (mainly smarter computer play-calling; Hard learns your tendencies). To keep games short, you pick ONE side, offense or defense; the computer plays the other. You pick a roster, which sets your team's strength.
- 2026-11-01: teams/rosters dropped for now (parked). A game is ONE drive: offense starts on its own 20 (80 yards to go). Touchdown = offense wins. Defense stops them under normal downs (4 downs to gain 10 yards) = defense wins.
- 2026-11-01: any offensive turnover (interception, fumble) = defense wins. Safety = defense wins. No field goals: touchdown or nothing. First playbook draft in PLAYBOOK.md (10 offense, 7 defense).
- 2026-11-01: prototype set chosen: offense Inside Run, Outside Run, Screen, Play-Action Deep; defense Cover 2, Man (Cover 1), Zone Blitz, Run Stuff. 4x4 matchup grid drafted in PLAYBOOK.md.
- 2026-11-01: named **PlayCaller**. Prototype play set + matchup grid accepted as the starter.
- 2026-11-01: **prototype built.** Result decided first (matchup edge + randomness), then the animation is scripted to match it. Balance check (simulated): random calls win ~26–34% on offense; always running Inside Run vs Hard wins ~1%.
- 2026-11-01: fix: Medium/Hard treated 1st & 10 as long yardage (Cover 2 ~half the time on first down). Now neutral: even mix on 1st & 10; long = 2nd+ & 8+, 3rd+ & 6+, or more than 10 to go.
- 2026-11-01: Play-Action Deep now has four targets/routes: outside go (35%), post to the middle (25%), slot seam (25%), TE corner (15%), either side. Nearest defensive backs react to wherever the ball goes.
- 2026-11-01: line play: each defensive lineman is paired with a blocker and they move together the whole time (hand-fighting wobble). Passes: set back, pocket slowly gives. Runs: line drives forward if the play won, gets pushed back if the defense won.
- 2026-11-01: public on GitLab (MIT): https://gitlab.com/samurailostinjapan/PlayCaller. Web build via pygbag works locally; GitHub Pages site not created yet.
- 2026-11-01: live on GitHub Pages: https://samurailostinjapan.github.io/playcaller/ (publish with ./publish-web.sh). Esc in the browser returns to the menu instead of killing the game.
- 2026-11-01: balance: Play-Action Deep was the jackpot (always-PA beat Hard 40% vs random 30%; 19% of drives scored in 2 plays). Deep catches now 18-40 yds, break for a TD 14% (+) / 6% (even) / 2% (-), was 35%/15%; Hard leans on your habits harder (2.4, was 1.6). Now vs Hard: random 23%, always-PA 24%, mixing best.
