# PlayCaller

**Play in your browser:** https://samurailostinjapan.github.io/playcaller/

A football play-calling game (working title chosen 2026-11-01).

A side project, built a little at a time. Decisions so far are in the Log at the bottom.

## The idea (2026-11-01)

A football game where **both sides call their own plays**, then **the players move according to the play** and the result comes out of how the two calls meet on the field.

## Play it

```
cd ~/PlayCaller
py main.py          # or: python -m playcaller
```

Needs `python-pygame` (pacman). Pick a side (1/O offense, 2/D defense) and a difficulty (1–3). Each down: pick a group (1–2, or R/P on offense, Z/A on defense), then the play (1–3 or arrows), Enter to snap, Backspace to go back. Space skips the animation / goes to the next play. Esc goes back to the menu.

Touch screens (tablet/phone browser) and the mouse work too: tap a menu line, tap a card to highlight it and tap it again to snap, and the buttons in the panel do what their keys do (tapping the field also works like Space).

On a phone (screen under 600 px on its short side) the game switches to **phone mode**: hold it sideways; the field fills the left, zoomed in around the ball, and a side panel holds big play cards and buttons. Try it on the desktop with `PLAYCALLER_PHONE=1 py main.py` (or `=800` for a narrower phone).

Tests: `python -m unittest` (rules, plus 1,500 random plays checked to stay on the field and end where the result says).

## Web build (no install for players)

Built with [pygbag](https://pypi.org/project/pygbag/) (installed in `~/.venvs/pygbag`, not system-wide):

```
~/.venvs/pygbag/bin/python -m pygbag --build --ume_block 0 --title PlayCaller ~/PlayCaller
~/.venvs/pygbag/bin/python -m pygbag --ume_block 0 ~/PlayCaller     # local test server: http://localhost:8000
```

Test with pygbag's own server, not a plain `http.server`: on localhost the page fetches pygame from `/cdn/...`, which only pygbag's server proxies. `build/web/` (index.html, playcaller.apk, favicon.png) is the whole website. The browser downloads a WebAssembly Python + pygame from pygbag's CDN the first time, then runs the game. Noto Sans is bundled (SIL OFL, `playcaller/assets/OFL-NotoSans.txt`).

**Publish:** `./publish-web.sh` builds with pygbag and pushes `build/web` to the GitHub Pages repo (github.com/samurailostinjapan/playcaller). That repo only holds the built site; the code lives here on GitLab.

## Code

- `playcaller/plays.py`: the four plays per side and the matchup grid
- `playcaller/engine.py`: drive rules (downs, touchdown, safety, turnovers) and how a play's result is decided
- `playcaller/ai.py`: the computer's calls (Easy random, Medium situational, Hard also learns your habits)
- `playcaller/anim.py`: turns a result into 22 moving players + the ball
- `playcaller/render.py`, `playcaller/main.py`: the Pygame window, screens and input

## How it works

1. **Call:** offense picks formation + play (routes, run direction, blocking); defense picks front + coverage (man, zone, blitz). Both lock in without seeing the other.
2. **Snap:** players follow their assignments — receivers run routes, linemen block, defenders cover or rush.
3. **Resolve:** matchups decide the outcome (blitz gets home? receiver open? hole there?), with player ratings and some randomness.
4. **Result:** yards, down and distance, then the next call.

The hard and fun part is step 2: 22 players moving believably from simple rules. A top-down 2D field with simple figures to start.

## Open questions

- Matchup grid in PLAYBOOK.md: does it feel right?
- Depth: a few simple plays and quick drives, or a real playbook with custom plays and ratings?

## Later (parked)

- Rosters / team strength (preset teams or build-your-own).

## Log

- 2026-11-01: idea, folder created.
- 2026-11-01: American football. Modes: player vs computer and player vs player. Python desktop app with Pygame (`python-pygame` from extra; not installed yet).
- 2026-11-01: two-player dropped. Player vs computer only, with difficulty levels (mainly smarter computer play-calling; Hard learns your tendencies). To keep games short, you pick ONE side, offense or defense; the computer plays the other. You pick a roster, which sets your team's strength.
- 2026-11-01: teams/rosters dropped for now (parked). A game is ONE drive: offense starts on its own 20 (80 yards to go). Touchdown = offense wins. Defense stops them under normal downs (4 downs to gain 10 yards) = defense wins.
- 2026-11-01: any offensive turnover (interception, fumble) = defense wins. Safety = defense wins. No field goals: touchdown or nothing. First playbook draft in PLAYBOOK.md (10 offense, 7 defense).
- 2026-11-01: prototype set chosen: offense Inside Run, Outside Run, Screen, Play-Action Deep; defense Cover 2, Man (Cover 1), Zone Blitz, Run Stuff. 4x4 matchup grid drafted in PLAYBOOK.md.
- 2026-11-01: named **PlayCaller**. Prototype play set + matchup grid accepted as the starter.
- 2026-11-01: **prototype built.** Result decided first (matchup edge + randomness), then the animation is scripted to match it. Balance check (simulated): random calls win ~26–34% on offense; always running Inside Run vs Hard wins ~1%.
- 2026-11-01: fix: Medium/Hard treated 1st & 10 as long yardage (Cover 2 ~half the time on first down). Now neutral: even mix on 1st & 10; long = 2nd+ & 8+, 3rd+ & 6+, or more than 10 to go.
- 2026-11-01: Play-Action Deep now has four targets/routes: outside go (35%), post to the middle (25%), slot seam (25%), TE corner (15%), either side. Nearest defensive backs react to wherever the ball goes.
- 2026-11-01: line play: each defensive lineman is paired with a blocker and they move together the whole time (hand-fighting wobble). Passes: set back, pocket slowly gives. Runs: line drives forward if the play won, gets pushed back if the defense won.
- 2026-11-01: public on GitLab (MIT): https://gitlab.com/samurailostinjapan/PlayCaller. Web build via pygbag works locally; GitHub Pages site not created yet.
- 2026-11-01: live on GitHub Pages: https://samurailostinjapan.github.io/playcaller/ (publish with ./publish-web.sh). Esc in the browser returns to the menu instead of killing the game.
- 2026-11-01: balance: Play-Action Deep was the jackpot (always-PA beat Hard 40% vs random 30%; 19% of drives scored in 2 plays). Deep catches now 18-40 yds, break for a TD 14% (+) / 6% (even) / 2% (-), was 35%/15%; Hard leans on your habits harder (2.4, was 1.6). Now vs Hard: random 23%, always-PA 24%, mixing best.
- 2026-11-01: 6 plays a side. New: Draw, Quick Slants (offense); Cover 3, Prevent (defense). Two-step picker: Run/Pass (offense) or Zone/Attack (defense) first, then the play (1-3, Backspace back). 6x6 grid in PLAYBOOK.md; tuned so no single play dominates (Inside vs Cover 3 even, Outside vs Cover 2 even, slants gain a bit less).
- 2026-11-01: **full drafted playbook in: 10 offense × 7 defense.** New: QB Sneak, Flats, Crossers, Four Verticals; Cover 0 Blitz. Offense picker now has three groups: Run / Short / Deep. Easy only sneaks on short yardage. Grid retuned so no single play dominates (see PLAYBOOK.md). Next: animation upgrades (route preview, ball flight, tackles, camera, replay, player looks, trails, field polish).
- 2026-11-01: animation #1 **route preview**: highlight a play in the picker and your side's routes, runs, blitzes and drops draw on the field as arrows (offense shown vs Cover 2, defense vs Four Verticals; the CPU's call stays hidden).
- 2026-11-01: animation #2 **ball flight**: throws rise with distance (flat on slants, a rainbow on deep shots), the ball points where it's going with a spiral wobble and laces, the shadow shrinks and fades as it climbs; deep balls hang a little longer.
- 2026-11-01: animation #3 **tackles and finishes**: impact ring + dust on tackles, tackled/sacked players lie flat, the picker leaps on interceptions, incomplete passes skip on the turf, confetti + bounce on touchdowns, pop-up words (SACK!, PICKED OFF!, FUMBLE!, TOUCHDOWN!, INCOMPLETE).
- 2026-11-01: animation #4 **follow camera**: during the play the view zooms in (1.3x) and eases along with the ball; the picker stays on the full field so the route arrows fit. C toggles follow cam / full field.
- 2026-11-01: animation #5 **slow motion + replay**: big moments (interception, sack, fumble, TD, catches of 15+) drop to 30% speed for about a second live; R after any play replays it at half speed with a REPLAY tag, starting 1.5 s before the big moment (whole play if none).
- 2026-11-01: animation #6 **player looks** (drawn in code, no assets): top-down figures with shoulder pads in team color, helmet + face mask facing where they move, striding feet, jersey numbers by position; tackled players lie stretched out. Drawn at 2x and smoothly scaled for clean edges.
- 2026-11-01: playtest notes, left as is for now: Four Verticals connects ~27% overall (39% with the edge); option on the table = more catches, shorter gains (12-30). Draw vs Zone Blitz breakaways (6% roll, 40+ yds <1%); option = 3% and 10-25 extra.
