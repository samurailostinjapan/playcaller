"""Rule checks: python -m unittest (from the PlayCaller folder)."""
import random
import unittest

from playcaller.engine import Drive, Result
from playcaller.anim import build
from playcaller.plays import OFFENSE, DEFENSE
from playcaller.ai import _bucket, _situation_weights
from playcaller.plays import GRID, OFFENSE_GROUPS, DEFENSE_GROUPS


def res(kind, yards):
    return Result("Inside Run", "Cover 2", 0, kind, yards)


class Rules(unittest.TestCase):
    def test_first_down_resets(self):
        d = Drive(); d.apply(res("run", 4)); d.apply(res("run", 7))
        self.assertEqual((d.down, d.to_go, d.spot), (1, 10, 31))

    def test_turnover_on_downs(self):
        d = Drive()
        for _ in range(4):
            d.apply(res("run", 1))
        self.assertTrue(d.over); self.assertEqual((d.winner, d.reason), ("defense", "Turnover on downs"))

    def test_touchdown(self):
        d = Drive(spot=95); d.apply(res("run", 5))
        self.assertEqual((d.winner, d.reason), ("offense", "Touchdown"))

    def test_safety(self):
        d = Drive(spot=3); d.apply(res("sack", -3))
        self.assertEqual((d.winner, d.reason), ("defense", "Safety"))

    def test_turnover(self):
        for kind in ("interception", "fumble"):
            d = Drive(); d.apply(res(kind, 0))
            self.assertEqual(d.winner, "defense")

    def test_goal_to_go(self):
        d = Drive(spot=95)
        self.assertEqual(d.line_to_gain, 100)
        self.assertIn("Goal", d.situation())

    def test_scenes_stay_on_field_and_end_at_result(self):
        rng = random.Random(11)
        for _ in range(1500):
            d = Drive(spot=rng.randint(1, 99))
            r = d.resolve(rng.choice(OFFENSE), rng.choice(DEFENSE), rng)
            s = build(r, d.spot, rng)
            for i in range(int(s.duration / 0.1) + 2):
                for p in s.players:
                    x, y = p.path.at(i * 0.1)
                    self.assertTrue(-10 <= x <= 110 and 0 <= y <= 53.4)
            if r.kind in ("run", "catch", "sack"):
                self.assertAlmostEqual(s.ball.at(s.duration)[0], d.spot + r.yards, delta=0.6)

    def test_down_and_distance_buckets(self):
        self.assertEqual(_bucket(1, 10), "medium")     # 1st & 10 is neutral
        self.assertEqual(_bucket(2, 9), "long")
        self.assertEqual(_bucket(3, 7), "long")
        self.assertEqual(_bucket(1, 15), "long")       # after a sack / big loss
        self.assertEqual(_bucket(3, 2), "short")

    def test_grid_and_groups_cover_every_play(self):
        self.assertEqual(set(GRID), set(OFFENSE))
        for o in OFFENSE:
            self.assertEqual(set(GRID[o]), set(DEFENSE))
        self.assertEqual(sorted(p for g in OFFENSE_GROUPS.values() for p in g), sorted(OFFENSE))
        self.assertEqual(sorted(p for g in DEFENSE_GROUPS.values() for p in g), sorted(DEFENSE))
        for side, plays in (("offense", OFFENSE), ("defense", DEFENSE)):
            for down, to_go in ((1, 2), (1, 10), (3, 12)):
                self.assertEqual(set(_situation_weights(side, down, to_go)), set(plays))

    def test_easy_only_sneaks_on_short_yardage(self):
        from playcaller.ai import Computer
        cpu = Computer("Easy", "offense", random.Random(5))
        self.assertNotIn("QB Sneak", {cpu.call(3, 8) for _ in range(500)})
        self.assertIn("QB Sneak", {cpu.call(3, 1) for _ in range(500)})


if __name__ == "__main__":
    unittest.main()
