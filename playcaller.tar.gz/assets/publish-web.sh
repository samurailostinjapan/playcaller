#!/usr/bin/env bash
# Build the browser version with pygbag and publish it to GitHub Pages.
# Code lives on GitLab; this pushes ONLY the built website to
# github.com/samurailostinjapan/playcaller  ->  https://samurailostinjapan.github.io/playcaller/
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
PYGBAG="$HOME/.venvs/pygbag/bin/python"
SITE_REPO="https://github.com/samurailostinjapan/playcaller.git"
SITE="$HERE/build/site"

# --ume_block 0: no "Ready to start, click/touch page" wait (that is for sound, and PlayCaller has none).
# On a phone the canvas fills the screen and iOS never turns those touches into the click it waits for.
"$PYGBAG" -m pygbag --build --ume_block 0 --title PlayCaller "$HERE"

if [ ! -d "$SITE/.git" ]; then
    git clone -q "$SITE_REPO" "$SITE" 2>/dev/null || { mkdir -p "$SITE"; git -C "$SITE" init -q -b main; git -C "$SITE" remote add origin "$SITE_REPO"; }
fi
git -C "$SITE" pull -q --ff-only origin main 2>/dev/null || true

# replace the site contents with the fresh build (keep .git)
find "$SITE" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -r "$HERE/build/web/." "$SITE/"
touch "$SITE/.nojekyll"
cat > "$SITE/README.md" <<MD
# PlayCaller (web build)

Play: https://samurailostinjapan.github.io/playcaller/

This repo only holds the built website (made with pygbag). Source code: https://gitlab.com/samurailostinjapan/PlayCaller (MIT).
MD

COMMIT="$(git -C "$HERE" rev-parse --short HEAD)"
git -C "$SITE" add -A
if git -C "$SITE" diff --cached --quiet; then
    echo "Site already up to date."
else
    git -C "$SITE" commit -q -m "Web build from PlayCaller $COMMIT"
    git -C "$SITE" push -q -u origin main
    echo "Published build of $COMMIT -> https://samurailostinjapan.github.io/playcaller/"
fi
