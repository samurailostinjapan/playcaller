"""Launcher: py main.py (desktop). The web build (pygbag) also starts here.

pygbag scans THIS file's imports to decide which libraries to load in the
browser, so pygame must be imported here even though the game code imports it too.
"""
import asyncio

import playcaller  # noqa: F401  (first: quiets pygame's banner and AVX2 warning)
import pygame  # noqa: F401  (needed by pygbag's package scan)

from playcaller.main import amain

asyncio.run(amain())
